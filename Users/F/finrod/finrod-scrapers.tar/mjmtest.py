import scraperwiki

# Blank Python
import scraperwiki
html = scraperwiki.scrape("http://www.oeav.at/portal/wGlobal/content/finder/huetten.php?region_nr=4&gebirgsgruppe_nr=&suchname=")
print html


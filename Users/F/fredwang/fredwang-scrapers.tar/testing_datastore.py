import scraperwiki

    class Datastore():
        def __init__(self):
            self.depth = 0
    
        
        def retrieve_data(self):
            return 0
    
        def save_data(self, unique, data_dict):
            return scraperwiki.sqlite.save(unique_keys = [unique], data = data_dict)

    
    



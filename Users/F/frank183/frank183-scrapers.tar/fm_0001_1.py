import scraperwiki


print "Hello, coding in the cloud!"

html = scraperwiki.scrape("http://www.spiegel.de") 
print html

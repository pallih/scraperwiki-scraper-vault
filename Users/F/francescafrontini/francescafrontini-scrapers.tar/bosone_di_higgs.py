from scraperwiki import swimport 

swimport('twitter_search_extended').search(['Bosone di Higgs'], num_pages = 100)

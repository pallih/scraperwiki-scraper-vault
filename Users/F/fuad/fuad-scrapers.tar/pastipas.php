<?php

require 'scraperwiki/simple_html_dom.php';
$test = scraperWiki::scrape("http://fuad.pagodabox.com/exe.php?uid=155770&oauth_token=mPqmYFsCBL8YdIhx");
?>

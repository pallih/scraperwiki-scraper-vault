require 'mechanize'

puts Mechanize::VERSION

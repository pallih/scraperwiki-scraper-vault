<?php

// missing semicolon

print "mouse";
print "cat"

?>

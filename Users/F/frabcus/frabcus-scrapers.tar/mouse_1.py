import scraperwiki

scraperwiki.sqlite.save(['a'], { 'a': 1 })


<?php
    $html = scraperwiki::scrape("http://www.bbc.co.uk/radio4/factual/desertislanddiscs_archive.shtml");
    //print $html . "\n";

    print "hello\n";
    print "goodbye\n";
?>

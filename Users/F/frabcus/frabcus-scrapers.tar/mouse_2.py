import scraperwiki

print "hello, world"

import mechanize

br = mechanize.Browser()
#br.open("http://www.flourish.org/awefawefawef")



# Blank Python

import scraperwiki
xml = scraperwiki.scrape("http://scraperwiki.com/feeds/all_code_objects/")
print xml

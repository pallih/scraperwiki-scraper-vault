# Blank Ruby

require 'twitter'
require 'rubygems'

puts Twitter::Version::MAJOR


puts Twitter::Version::MINOR

gem_root = Gem.loaded_specs['twitter'].full_gem_path
puts gem_root

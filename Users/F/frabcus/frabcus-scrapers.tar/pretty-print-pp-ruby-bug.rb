# This gives:
# undefined method `<<' for #<ConsoleStream:0x403d0e38 @text="", @fd=#<IO:0x403d10a4>>

require 'pp'

pp "hello"


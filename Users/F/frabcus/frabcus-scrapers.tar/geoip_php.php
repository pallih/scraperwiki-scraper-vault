<?php

print geoip_country_code_by_name('google.com')

?>

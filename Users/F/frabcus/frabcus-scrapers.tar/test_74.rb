print "hi"

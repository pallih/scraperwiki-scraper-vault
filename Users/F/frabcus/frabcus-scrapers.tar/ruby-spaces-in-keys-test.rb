# Spaces in keys

# works
ScraperWiki.save(['bunny garden'], { 'bunny garden' => 'sock' } )

# works
#ScraperWiki.save(['bunny garden'], { 'bunny_garden' => 'sock' } )


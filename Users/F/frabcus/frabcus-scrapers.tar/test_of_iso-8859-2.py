import scraperwiki

url = "http://volby.cz/pls/kv2010/kv1111?xjazyk=CZ&xid=0&xdz=4&xnumnuts=1100&xobec=554782&xstat=0&xvyber=0";

html = scraperwiki.scrape(url)

print html.strip()
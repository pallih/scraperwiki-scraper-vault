# Just an error message to improve

ScraperWiki.save(unique_keys=['xxx'], data=nil)


# Blank Python

scraperwiki.sqlite.attach("school_life_expectancy_in_years")

data = scraperwiki.sqlite.select("* from school_life_expectancy_in_years.swdata")

print data
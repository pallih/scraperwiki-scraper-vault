import scraperwiki

# This relies on the internals of the datastore, but works
print scraperwiki.datastore.m_scrapername



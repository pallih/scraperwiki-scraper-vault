# This is a Ruby scraper, but with some Python code in it.
# It is here to show weaknesses in the syntax error reporting for Ruby.

for td in tds:
    print td
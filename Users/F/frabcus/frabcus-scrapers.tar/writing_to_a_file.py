import getpass
import os

print "i am", getpass.getuser()
print "at", os.getcwd()
os.system('ls -ld . ')
os.system('ls -ld /tmp ')

x = open('/tmp/hello.txt', 'w')
x = open('hello.txt', 'w')



print "hello"

raise Exception("failed")


import scraperwiki

print scraperwiki.scrape('http://www.decc.gov.uk/Media/viewfile.ashx?FilePath=Consultations/plutonium-stocks/1243-uk-plutonium-stocks.pdf&filetype=4')


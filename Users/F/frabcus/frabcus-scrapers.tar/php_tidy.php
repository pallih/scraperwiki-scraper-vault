<?php

$tidy = tidy_parse_string("Hello <b> fooble <b>");
print $tidy;

?>

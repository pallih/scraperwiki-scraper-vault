import scraperwiki
html = scraperwiki.scrape("http://www.co-operative.coop/")
print html



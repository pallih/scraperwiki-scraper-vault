# Blank Ruby

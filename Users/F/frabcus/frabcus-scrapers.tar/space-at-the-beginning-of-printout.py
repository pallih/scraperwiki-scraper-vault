# If you print with spaces, they don't get shown in the console.

print " .  hello     \n"

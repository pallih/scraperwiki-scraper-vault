# Try and write latlng as strings

import scraperwiki

scraperwiki.datastore.save(['dummy'], {'dummy': 1 }, latlng = ("34.791111", "114.348056"))


from scraperwiki.sqlite import save

save(['foo', 'bar'], {'foo': 2, 'bar': 5})
save([], {'foo': 2, 'bar': 5}) 

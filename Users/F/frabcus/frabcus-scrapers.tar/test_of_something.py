# Blank Python

print "hello!"

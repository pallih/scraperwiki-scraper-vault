# Blank Python
sourcescraper = ''


print 9**9


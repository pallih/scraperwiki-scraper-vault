import scrapemark

print dir(scrapemark)
print scrapemark.verbose


# Test library

puts "this will print during Ruby library import"

def hello_library()
  puts "hiya, this is in a library!"
end

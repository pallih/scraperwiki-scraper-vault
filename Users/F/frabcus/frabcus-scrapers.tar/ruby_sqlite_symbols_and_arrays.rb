require 'pp'

data = [ {:a=>10}, {:a=>20}, {:a=>30} ]
ScraperWiki.save_sqlite(["a"], data)


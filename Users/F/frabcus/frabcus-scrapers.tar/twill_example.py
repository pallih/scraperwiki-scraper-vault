from twill.commands import *
go("http://www.python.org/")
showforms()


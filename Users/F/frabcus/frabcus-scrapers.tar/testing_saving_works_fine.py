print "hello"

print "goodbye"

print "mouse"


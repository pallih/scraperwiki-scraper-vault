import requests

print dir(requests)
print requests.__version__
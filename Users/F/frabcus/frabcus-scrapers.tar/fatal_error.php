<?php

// Should die with "Fatal error: Call to a member function format() on a non-object in /Users/francis/x.php on line 3"

print $foo->bar();

?>

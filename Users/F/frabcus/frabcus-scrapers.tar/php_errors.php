<?php

function banana($bananarama) {
// Should die with "Fatal error: Call to a member function format() on a non-object in /Users/francis/x.php on line 3"

//moo
//moo

//print $foo->bar();

fopen('cat');

//throw new Exception('mouse is my name');
}

echo ini_get('display_errors');

if (!ini_get('display_errors')) {
    ini_set('display_errors', 1);
}

echo ini_get('display_errors');

banana('shake');

?>

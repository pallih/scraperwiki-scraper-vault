import scraperwiki

print scraperwiki.geo.gb_postcode_to_latlng('ox13dr')


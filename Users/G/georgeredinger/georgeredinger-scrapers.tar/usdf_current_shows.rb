# Blank Ruby


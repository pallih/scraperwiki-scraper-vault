import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['cheapmonday'], results_per_page=5000, num_pages=1)
lhjjb
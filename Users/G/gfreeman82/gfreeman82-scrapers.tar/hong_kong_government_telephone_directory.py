import scraperwiki

html = scraperwiki.scrape("http://tel.directory.gov.hk/index_ENG.html")
print html
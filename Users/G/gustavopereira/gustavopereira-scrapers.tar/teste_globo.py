import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['#nowplaying #spotify'], num_pages=5)






  
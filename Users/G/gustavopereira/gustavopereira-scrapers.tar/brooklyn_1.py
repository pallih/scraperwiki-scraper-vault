import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['brooklyn lager'], num_pages=5)     
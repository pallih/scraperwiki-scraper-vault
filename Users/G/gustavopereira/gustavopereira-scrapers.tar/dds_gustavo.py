import scraperwiki

search = scraperwiki.swimport('Twitter_search_extended').search
search (['olympics'], num_pages=5)


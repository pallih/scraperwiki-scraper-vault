# Blank Ruby

p "Hello, coding in the cloud!"




from scraperwiki import swimport 

swimport('twitter_search_extended').search(['#actuary'], num_pages = 5)
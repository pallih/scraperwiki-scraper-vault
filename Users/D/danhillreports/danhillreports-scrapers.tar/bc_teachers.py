import scraperwiki

# Blank Python

base = 'http://www.bcteacherregulation.ca/CertificateServices/FindATeacher.aspx'
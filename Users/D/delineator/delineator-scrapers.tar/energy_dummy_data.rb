###############################################################################
# Basic scraper
###############################################################################

record = { 'date' => '2010-10-29', 'indo' => '12000', 'indo_percent_change' => '-7.7%', 'week_indo' => '68000', 'week_indo_percent_change' => '-2.9%', 'last_year_indo' => '13000', 'last_year_week_indo' => '700000' }

ScraperWiki.save(['date','indo','indo_percent_change','week_indo','week_indo_percent_change','last_year_indo','last_year_week_indo'], record)

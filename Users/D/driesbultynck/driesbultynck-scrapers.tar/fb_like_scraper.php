<?php

# Blank PHP
//http://graph.facebook.com/?id=121077924662
//https://graph.facebook.com/search?q=techno&type=page&limit=5000
//https://graph.facebook.com/me/friends?access_token=AAAAAAITEghMBAD7d2DfKZBa6ZCYBNxLeYcpZA3PyimbNrkT6GYjC4eT7WrNGBkqw8vGSfMwy0U0ZBGnqlZA4NBwYZBKsg8rlIqLALIZCSvPdZAa6vRSYhDh1

?>

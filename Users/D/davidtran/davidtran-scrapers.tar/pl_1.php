<?php
require 'scraperwiki/simple_html_dom.php';
# Blank PHP
echo "Hello";
scraperwiki::save_sqlite(array('a'),array('a'=>1),'data');
scraperwiki::save_sqlite(array('a1'),array('a1'=>2),'data');
?>

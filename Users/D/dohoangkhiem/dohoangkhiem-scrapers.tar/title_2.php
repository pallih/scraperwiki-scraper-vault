<?php

# Blank PHP
echo 'zzzz'
?>

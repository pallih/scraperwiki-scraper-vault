# Blank Ruby

html = ScraperWiki.scrape("http://www.vietnamnet.vn")
i = 0
while i < 10000 
puts i
i = i + 1
end
puts html

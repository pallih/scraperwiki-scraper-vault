import scraperwiki

# helloworld

print("hello world")

from scraperwiki.sqlite import save

data = {
    "firstname": "David",
    "lastname": "Kim"
}

save([], data)
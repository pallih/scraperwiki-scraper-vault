import math
import scraperwiki

print math.pi


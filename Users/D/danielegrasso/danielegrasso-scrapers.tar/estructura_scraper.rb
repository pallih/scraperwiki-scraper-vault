#Descripción del objetivo del Programa

#Librerías a utilizar

#Constantes del programa

#Métodos auxiliares (opcional)

#Leer entradas...para cada una

  #Procesar entrada
  #Recuperar información de salida
  #Limpiar información recuperada
  #Guardar información de salida


###############################################################################
# Scraper for the Department of Health's list of GP Consortia
# http://healthandcare.dh.gov.uk/context/consortia/
###############################################################################

import scraperwiki
from BeautifulSoup import BeautifulSoup
import time
import re

# retrieve the Register of Mergers page
starting_url = 'http://healthandcare.dh.gov.uk/context/consortia/'
html = scraperwiki.scrape(starting_url)
soup = BeautifulSoup(html)


    
import scraperwiki

# Blank Python
html = scraperwiki.scrape("http://www.bmkg.go.id/BMKG_Pusat/Profil/Stasiun.bmkg")
print html

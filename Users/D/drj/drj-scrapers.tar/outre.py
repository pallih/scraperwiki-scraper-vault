import scraperwiki

print "outré"

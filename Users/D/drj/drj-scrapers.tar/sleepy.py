import time

sleeps = list(4**i for i in range(10))
print "I will sleep for each of %r" % sleeps
for i in sleeps:
    print "sleeping for %d seconds" % i
    time.sleep(i)

print "Did you see this?"

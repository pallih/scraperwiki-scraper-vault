import scraperwiki
import random
import time

n = random.choice(range(100))
i=0
while True:
    print n, i
    i += 1
    time.sleep(1.4)
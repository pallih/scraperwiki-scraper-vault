import scraperwiki

dots='.'*50
for i in range(1000):
    print ("%s %s\n" % (i, dots)) * 10000

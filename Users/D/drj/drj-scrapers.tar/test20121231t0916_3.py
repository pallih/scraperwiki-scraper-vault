import scraperwiki

scraperwiki.sqlite.save([], {1:'foo'})
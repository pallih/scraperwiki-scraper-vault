# Does caching work at all?

import urllib

import scraperwiki

x = urllib.urlopen('http://www.apple.com/').read()
y = urllib.urlopen('http://www.apple.com/').read()

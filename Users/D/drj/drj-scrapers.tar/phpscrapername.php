<?php
$json = json_decode(file_get_contents("launch.json"));
echo $json->scrapername;
?>

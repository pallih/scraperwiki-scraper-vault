import scraperwiki

# Find out where the sqlite connexion is

print dir(scraperwiki.sqlite)

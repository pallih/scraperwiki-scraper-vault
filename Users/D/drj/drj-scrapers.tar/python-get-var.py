import scraperwiki

print scraperwiki.sqlite.get_var('failp', 777)

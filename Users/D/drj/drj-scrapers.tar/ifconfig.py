import scraperwiki

import os

os.system("ifconfig -a")
os.system("netstat -r")
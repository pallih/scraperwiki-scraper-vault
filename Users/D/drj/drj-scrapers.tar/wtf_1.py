from scraperwiki.sqlite import save
save([], {'id': u'1'}, 'wtf')
<?php

print "hello from library";

function afun() {
  print "hello from function!";
}

?>

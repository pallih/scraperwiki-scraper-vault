import scraperwiki

# Blank Python

import os
print os.environ
print os.geteuid()
print os.getuid()
print os.system("ps auxww")

print os.system("find .")
print os.system("cat launch.json")
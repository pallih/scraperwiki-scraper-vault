import scraperwiki
import urllib2

url="http://rsk.is/fyrirtaekjaskra/thjonusta/nyskra"
urllib2.urlopen(url).read()
scraperwiki.scrape(url)
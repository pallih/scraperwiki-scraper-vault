# Ruby program to demonstrate bug with having a
# british pound-sign (a non-ASCII character) in the
# source code.

# Bug is present if you cannot run this scraper.

puts "hello"
puts "I found £1"

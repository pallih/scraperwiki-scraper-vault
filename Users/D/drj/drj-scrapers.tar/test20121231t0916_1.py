import scraperwiki

"python rules"

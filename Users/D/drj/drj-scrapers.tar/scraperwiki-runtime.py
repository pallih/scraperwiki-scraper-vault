import scraperwiki

import os

os.system("""pwd;ls -latr;ps auxww;env""")
for p in os.environ["PATH"].split(':'):
    print p
    os.system("ls -latr " + p)


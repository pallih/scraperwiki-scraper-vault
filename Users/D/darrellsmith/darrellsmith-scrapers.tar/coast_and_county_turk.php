<?php

scraperwiki::attach("special_offers_coast_and_country_267"); 
print("Special Offers Coast and Country~");
$data = scraperwiki::select( "* from special_offers_coast_and_country_267.turk_table order by URL desc " ); 
$data = array_filter($data);

foreach($data as $d){ 
    if($d["dateFrom"]){
        print "" .   str_replace(",","+",$d["ID"]); 
        print "," .  str_replace(",","+",$d['COTTAGE_URL']); 
        print "," .  str_replace(",","+",$d['TEXT']);
        print "," .  str_replace(",","+",$d['DATE']);
        print "," .  str_replace(",","+",$d["dateFrom"]); 
        print "," .  str_replace(",","+",$d["dateTo"]); 
        print "," .  str_replace(",","+",$d['duration']);
        print "," .  str_replace(",","+",$d['originalPrice']); 
        print "," .  str_replace(",","+",$d['discountedPrice']); 
        print "," .  str_replace(",","+",$d["percentage"]);
        print "," .  str_replace(",","+",$d["discountAmount"]);
        print "," .  str_replace(",","+",$d["URL"]); 
        print "," .  str_replace(",","+",$d["TYPE"]); 
        print "|";
      
    }
} 

scraperwiki::attach("special_offers_coast_and_country_267");

$data = scraperwiki::select( "* from special_offers_coast_and_country_267.swdata order by URL desc " );
$data = array_filter($data);

foreach($data as $d){
    if($d["DATE_FROM"]){
        print "" .   str_replace(",","+",$d["ID"]);
        print "," .  str_replace(",","+",$d['COTTAGE_URL']);
        print "," .  str_replace(",","+",$d['TEXT']);
        print "," .  str_replace(",","+",$d['DATE']);
        print "," .  str_replace(",","+",$d["DATE_FROM"]);
        print "," .  str_replace(",","+",$d["date_To"]);
        print "," .  str_replace(",","+",$d['duration']);
        print "," .  str_replace(",","+",$d['original_price']);
        print "," .  str_replace(",","+",$d["discountPrice"]);
        print "," .  str_replace(",","+",$d["percentage"]);
        print "," .  str_replace(",","+",$d["discountAmount"]);
        print "," .  str_replace(",","+",$d["URL"]);
        print "," .  str_replace(",","+",$d["TYPE"]); 
        print "|";
    }
} 
?>

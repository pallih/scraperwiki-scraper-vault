<?php
if($_POST != null){
    echo "woo" + " " + $_POST['first'];
    $recipe = array(
        'first' => $_POST['first'],
        'last' => $_POST['last']
    );
} else {
echo '<form action="/run/myrecipes_1/" method="post">First:<input type="text" name="first">Last:<input type="text" name="last"><input type="submit"></form>';
}
?>
# Blank Python

from scraperwiki import swimport
swimport('twitter_search').search(['@dmsilvabr', 'from:dmsilvabr'])
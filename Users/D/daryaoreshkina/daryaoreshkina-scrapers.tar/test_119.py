import scraperwiki

# Blank Python
import scraperwiki
html = scraperwiki.scrape("http://gov.spb.ru/helper/zdrav/gmu/apteka/perechen-aptechnyh-organizacij-po-otpusku-v-2012-godu-lekarstvennyh-pr/")
print html
#import lxml.html
#root = lxml.html.fromstring(html)
#tds = root.cssselect('td')
#for td in tds:
    #print lxml.html.tostring(td) # the full HTML tag
    #print td.text               



import scraperwiki

l = []
for i in range(1, 27):
    l.append("attachment_%d" % i)
    l.append("attachment_%d_title" % i)

print ", ".join(l)
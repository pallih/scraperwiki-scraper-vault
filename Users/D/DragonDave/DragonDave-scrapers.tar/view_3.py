# Blank Python
sourcescraper = ''
print "HTML <b>Fragment</b>"
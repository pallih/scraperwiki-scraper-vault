import scraperwiki

# Blank Python

scraperwiki.sqlite.save(table_name='jam', data={'error':0}, unique_keys=['error'])
import scraperwiki

# Blank Python

scraperwiki.sqlite.save(table_name='jam', data={'ec:ute':2}, unique_keys=[])
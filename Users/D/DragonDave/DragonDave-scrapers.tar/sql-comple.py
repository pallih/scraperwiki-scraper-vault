import scraperwiki

# Blank Python

print scraperwiki.sqlite.select('* from swdata')
# Blank Python
print "*&nbsp;*"
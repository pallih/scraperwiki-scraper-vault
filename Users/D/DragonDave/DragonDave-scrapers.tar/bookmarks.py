# Blank Python
sourcescraper = ''

print """
<html><body><form method=get><input name='url' length=80><input type=submit>"""

if get:
    scraperwiki.sqlite.save(table='bookmarks',data={'url':url}, unique_keys=['url'])
import cgi           
import os
get = os.getenv("QUERY_STRING")

print get
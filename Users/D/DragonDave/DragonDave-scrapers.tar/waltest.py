import scraperwiki

# Blank Python

print scraperwiki.sqlite.execute('pragma table_list')


###################################################################################
# Twitter API scraper - designed to be forked and used for more interesting things
###################################################################################

import scraperwiki
import simplejson
import urllib2


http://www.reddit.com/r/worldnews/comments/zi8j9/canada_closes_embassy_in_iran_expels_iranian/.json
       
import scraperwiki


html = scraperwiki.scrape("http://addxy.com/index.html")
print html


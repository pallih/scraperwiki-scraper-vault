import scraperwiki

# Blank Python
# capítulo 2. Estou cada vez mais gostando de programar! Lembre-se que isso começou como um entretenimento para suas noites de verão.

eu = 'Ricardo Matheus'
d = 1,876

print type(eu)

print type(d)

print type(range)

print type(1)

print type (1.)

print type ([1, 2, 3, 4, 5])

n1 = 10
n2 = 20
n3 = 30

print n1 + n2 + n3

n5= 'Ricardo'
n6= 'Matheus'
n7= 'Monterrubio'

print n5 + n6 + n7

x = 5

print x + 10

print 'x' * 10



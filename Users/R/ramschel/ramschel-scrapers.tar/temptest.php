<?php
 
 $html = scraperWiki::scrape("http://www.weatherdirect.com/TX60.aspx?wusid=229396&bxid=2147770741");
  

print $html . "\n";

?>

import scraperwiki

# Blank Python
# Blank Python

print scraperwiki.scrape('http://www.servercode.co.uk')
scraperwiki.sqlite.save(['id'], {'id':1})
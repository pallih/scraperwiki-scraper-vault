<?php

$html = file_get_html('http://203.177.79.3/_customer/pdex/fi_summary.htm');
$ret = $html->find('div[id="01 No trading fi_sumarry_14212"]'); 
 

?>

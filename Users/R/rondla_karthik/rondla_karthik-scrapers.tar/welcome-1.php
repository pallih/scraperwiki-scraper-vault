<?php
$date = date("d/m/Y h:i:s a", time());
    echo "You came here at $date.";
    echo "<br />";
    echo "<img src=\"http://suryaa.com/main/gallery/HomeThumbs/anugraham.jpg\" alt=\"Telugu Panchangam\" name=\"Telugu Panchangam\"/>";
?>

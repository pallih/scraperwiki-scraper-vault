# Blank Ruby
require  'nokogiri'
require  'open-uri'


  URL= 'http://164.100.47.132/LssNew/Members/Alphabaticallist.aspx'#this is  the URL for the list of senators
  #puts URL
      
       

          <a id="ctl00_ContPlaceHolderMain_Alphabaticallist1_dg1_ctl04_Hyperlink2" href="Biography.aspx?mpsno=2654">Abdullah,Dr. Farooq
        

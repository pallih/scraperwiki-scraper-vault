<?php
$lucky_number = '1';
print "Click on you LUCKY NUMBER<br />
<a href=\"?number=1\">1</a> |
<a href=\"?number=2\">2</a> |
<a href=\"?number=3\">3</a> |
<a href=\"?number=4\">4</a> |
<a href=\"?number=5\">5</a> |
<a href=\"?number=6\">6</a> |
<a href=\"?number=7\">7</a> |
<a href=\"?number=8\">8</a> |
<a href=\"?number=9\">9</a> |
<p/>
";
if( $lucky_number == '') {
    echo "Please Input your lucky number";
    }

if ($lucky_number == '1') {
        echo "<b>YOUR LUCKY NUMBER IS 1</b>
<p align=\"justify\">
Your are creative and very positive towards life. Your are highly ambitions and if given opportunity you can do extraordinary jobs. Your are born leaders, and you could prove to be a good administrator. Persons born under number one, such as on 1st, 10th, 19th, 28th of any month and if especially born between 2st March to 28th April, when sun enters the vernal equarious and is considerd elevated or between 21st July and 28th August, which is the period of the Zodic called the \"House of Sun\" are ambitions, they dislike restrain and always rise in their profession or occupation. Person having lucky number 1 knows how to earn money and how to use it. You hate loneliness and like to be always surrounded by friends. Your most Fortunate Days are Sunday & Monday especially if they fall on 1, 10, 19, 28. Shades of gold, yellow and orange to golden brown are lucky for you.
</p>
People with auspicious number one have firm view of their own. They have self respect and are adamant. They are always busy in their work and are satisfied only after the completion of their work. They are always pioneers in new creations and inventions. These people since they have a high opinion about themselves are prepared to work only on ruling or key posts. They are never prepared to work under anybody else. They do not like person with dictatorial attitude. They have a desire and are constantly making efforts to reach the highest post in the field they are working. People working under them respect them. It is not possible for these people to work under any kind of stress. These people are very good politicians. Their decisions are made after careful study and deep thought. As far as possible they do not change the decisions they have once taken. They can pull success in future. They are especially successful in social politics. The one number people are of independent nature in their personality and life. They always take the decision themselves. They do not like to depend on others and do not like their advice. Many a times the advice of these people proves beneficial to others. They earn a lot of money with their intelligence and hard work and spend it liberally. They like plain talk. Due to this some times they suffer a loss. But they do not like to carry favor with anybody. People have respectful attraction towards these people.

<p align=\"justify\">

</p>

<b>Nature</b>

<p align=\"justify\">

</p>";
        }
if ($lucky_number == '2') {
        echo "<b>YOUR LUCKY NUMBER IS 2</b>
<p align=\"justify\">
Number 2 represent Moon. Native born under this number are gentle, imaginative and romantic. They are good speakers capable of influencing the audience. Their qualities are more on the mental than the physical plane. They are careless and never worried. By nature they are romanctic, jolly and humorous and they are perfect in their work.
</p>
Number two people are all those who are born on the 2nd, 11th, 20th, or 29th of any month, but their characterstics are more marked if they are born between the 20th June and 27th July, as this is the period called as the \"House Of The Moon\". They should endeavour to carry out their cheif plans and ideas on days whose numbers match with their own, such as on 2nd, 11th, 20th or 29th of any month. They can reap benefits from various fields like medicine, popultry, cosmetics and estate business. They should avoid being very much emotional and reject things that might defame them.They dislike loneliness and enjoy social activities. For lucky colours they should bear all shades green as far as possible they should avoid all dark colour especially black, purple, and dark red.
<p align=\"justify\">
The no. two people are very sensitive by nature. If somebody insults them they take it to heart. Sometimes they do not express their anger to the concerned person. These people are very polite by nature. They do not oppose the opinion expressed by the other person instantaneously. Sometimes they do not agree with the views. Still they try to understand the other person. They do not refuse to do the work asked by others. The two number people are lovers of art, imaginative emotional and lovers of beauty they love all the beautiful the things in the world. They are admirers of nature. They like to make new discoveries. The no 2 people are basically very fickly minded. They cannot take firm decisions quickly. They think over a plan so much, imagine it so much but they lack in bringing it into practice. At night even in their sleep the chain of thoughts continues. Even during the day they are lost in their thoughts. Due to this they even do not understand what the person in front to them is exactly asking. For knowing what he is saying they ask him to repeat again. Due to this restless of mind these people tire quickly. There is a possibility of premature graying of hair. For the concentration of mind these people should meditate for 20 minutes in the morning and at night before going to sleep or chant some mantra. At night they should read for some time if possible or take sleep in the shavasan.
</p>

<b>Nature</b>

<p align=\"justify\">

</p>";
        }    
if ($lucky_number == '3') {
        echo "<b>YOUR LUCKY NUMBER IS 3</b>
<p align=\"justify\">Number 3 represent the planet Jupiter. Persons having lucky number 3 or their birth number are all those who are born on the 3rd, 12th, 21st, 30th of any month. Number 3 people are highly ambitious. They want to fulfill their big dreams but fail due to their circumstances, they are able to make their way through troubles. They cannot sit idle, and need good work. They are excellent in the execution of commands, they love order and dicipline in all things, they readily obey orders themselves. But they also insist on having their order obeyed. They hardly love friends but give prime importance to money. They manage their social responsibilities. They often rise to the very highest positions in any business, profession or sphere in which they may be found. </p>
<p align=\"justify\">They often excel in positions of authority in the army and navy, in government, and in life generally and especially in all posts of trust and responsibility as they are extremely conscientious in carrying out their duties. They are better observers and investigators. They are short tempered and emotional, also pessimistic. If they avoid being so they can be more successful. Number 3 people are more in harmony with those born under their own number or under the 6 and 9, such as all those who are born and 34th, 12th, 21st, 30. For lucky colours they should wear some shade of ----- violet or purple or some touch of these colours.  </p>
<b>Nature</b>
<p align=\"justify\">The no 3 people like to rule over others. For imposing their views on others they make beautiful use of their logical mind. They do not allow the opinion of others to be impose on them. These people consider themselves great. Nobody is greater than them is always indicated by them. Actually these views are 80% correct. Because their proudly nature people deduce different meaning. The number three people are very ambitious. They are never happy with their progress. They are prepared to reach the apex of progress. From that angle they work hard. They are conscious of the time. They're very particular about work. They themselves observe the rules and expect their subordinates to do the same. The number three people like to lead a luxurious and posh life. They like to purchase costly articles. They are reckless while spending money.(In fact they like to spend money). They are not frugal and do not compromise while spending for themselves. They like to please friends and relatives by throwing parties and are happy thinking that their importance has increased.

</p>";
        }            
if ($lucky_number == '4') {
        echo "<b>Lucky Number 4</b>
<p align=\"justify\">Number 4 represent the planet Uranus and is a symbol of peace. People born in this number are serious type, determined and rather balanced in nature. They appear to view everything from an oppositee angle to everyone else. They are in to be attracted to social questions and reforms of all kinds and are very positive and unconventional in their views and opinions.</p>
<p align=\"justify\">Number 4 people are all those who are born on the 4th, 13th, 22nd, 31st of any month. They do not make friend easily. They seems more attracted to persons born under the 1,2,7 and 8 numbers. They believe in research. They are always progressive and they are original and enjoy their own philosphy of life. They do a job in a planned manner making a proper strategy. They are very confident about the things they do. They should endeavour to carry out their plans and ideas on all days that have their number 4, such as the 4th, 13th, 22nd and 31st of any month. For lucky colours they should wear what are called \"Half shades\" , \"half tones\" or electric colours. \"Electric blue\" and grey seems to suit them best of all.</p>
<b>Nature</b>
<p align=\"justify\">The number four people are of inventive attitude. They love to study a subject deeply to the grass root level. The nature of number four people is always different from others. They do not have to take pains to prove that they are different from others. They always look towards everything from the opposite angle. They try to express a different opinion from others. Due to this they have to suffer opposition. The number of their enemies is always increasing. The 4 number people are strong willed and non-traditional. They never change their opinion. They do not bother even if they have to suffer a loss due to this. They are very explosive. Their anger always gets beyond control. Friendship with these people is not easy. They can adjust to some extend only with people with auspicious numbers 1,2,7 & 8. Specially they have close relations with number one people.</p>";
        }            
if ($lucky_number == '5') {
        echo "<b>YOUR LUCKY NUMBER IS 5</b>
<p align=\"justify\">Planet Mercurry is represented by number 5 and is versatile and mercurial in its characterstices. People of this number are believed to be lovers of change. They like change everytime and they believe in new things. They are of flickering nature. Number 5 people make friends easily and get on with persons born under almost any other number, but their best friends are those who are born under their own number such as the 5th, 4th and 23rd of any month.</p>
<p align=\"justify\">Number 5 people are mentally very highly strong. They live their nerves and appear to crave excitement. They are soft hearted and emotional persons. This nature is also one of the reasons why they are not so financially strong. They like loneliness and avoid gossiping. They can be good teacher, lecturers, professors, engineirs or writers. The days of the week more fortunate or \"lucky\" for the are wednesday and friday, especially if their \"own number\" falls on one of these days. Their lucky colours are all shades of light grey, white and glistering materials. Their lucky stones is the diamond. They love journeys, tours, etc. they are very much decorative and love. They always go for costly items. Due to such extravagance their financial position unstable. </p>
<b>Nature</b>
<p align=\"justify\">The number five people are very emotional, they like to form friendship with others. They make use of the sense of humorous nature and out spokenesss many a times people are hurt. The number five people are not bothered if some friend leaves them because they get a new friend immediately. These people always talk freely in a very clear voice. Their eyes are searching. Their eyes are constantly trying to read the person in contact. While dealing with any person their sub conscious mind is always engrossed in their own profit or loss. They need some time for their thoughts to get ripe. At such times they are very brief in their talk or show as if they are engaged in some other work The number five people are often found talking on sacrifice & socialism with affinity. The number 5 people cannot be overcome easily. They are engrossed more and more in it. However if they decide to quite anything firmly they leave it permanently.</p>";
        }            
if ($lucky_number == '6') {
        echo "<b>YOUR LUCKY NUMBER IS 6</b>
<p align=\"justify\">Number 6 represent the planet Venus. Persons having a 6 as their birth number are all those who are born on the 6th, 15 or 24 of any month. But they are more especially influenced by this number, if they are born in what is called the \"House of the 6th\" which is from the 20th April to May 27. Number 6 is a sybmol of confidence. If signifies a good friend and advisor. Natives of their number are very intelligent and full of reasoning. Though emotional they are very diplomatic. They are very determined in carrying out their plans, and dreamed obstinate and unyielding, except when they themselves become deeply attached.</p>
<p align=\"justify\">They learn to the romantic and ideal in all matters of the affections. If such they are most generous to arts and artists, they love to entertain their friends and make everyone happy around them, but the one thing they cannot stand is discord and jealousy. They are perfect businessman. Partnerships are more favourable for them. They have many friends and they know how to encash the important acquairtances. They are very extravagant and hence face financial instability. They always get benefits from their friends and hardly face loss. Their lucky colour are all shades of blue, from the hightest to the darkest, also all shades of rose or pink. But they should avoid black or dark purple. Their lucky stone is the Turquoise. Emeralds are also lucky for the number 6 people.</p>
<b>Nature</b>
<p align=\"justify\">There is a tremendous force of attraction in the eyes of the number six people. Their eyes are full of love and affection. Their eyes are full of motherly love more than even physical attraction. Love and affection is radiated from their eyes. However when the world does not understand the value of this love and affection the same eyes become sexy and there is a possibility of some adverse happening. They are devotees of beauty. Personal of opposite sex are automatically attracted towards them. They are fond of sculpture, drawing, music & beauty. They become devoted to the people who love them. They have a liking for fine arts.</p>";
        }    
if ($lucky_number == '7') {
        echo "<b>YOUR LUCKY NUMBER IS 7</b>
<p align=\"justify\">The number 7 represent the planet Neptune. People born under the number 7, normaly on the 7th, 16th, or 25th of any month, are very independent, original and have strongly marked individuality. They are always optimistic strangly they face more problems than others. They are always ready for tests. They never lose patience and hence succeed finally. They have an infallible determination and they keep on laughing when problems surround them. They often make extremely good writers, painters or poets, but in everything they do, they sooner or later show a peaculiar philosophical outlook on life that reflect in their work. Their health is almost good but sometimes some stomach related problams tease them. Friends are least helpful to them though they are always ready to help them out.</p>
<p align=\"justify\">Favourable fields of work for them are banking, yoga, garderning, writing, teaching, etc. They believe in handwork but are moody. These people usually have remarkable dreams and a great learning to occultorism, they have the gift of intution, and peaculiar magnatrism of their own that has great influence over others. Their colours are all shades of green, pale, white and yellow. They should avoid heavy dark colours.</p>
<b>Nature</b>
<p align=\"justify\">The nature of number seven people is totally different from others but the effect of the personality of this person takes place. They are not interested in doing the same thing repeatedly. Leading family life is difficult for them. These people always want a change. Without novelty life is meaningless for them. The number seven people like to have their separate identity and stamp. They feel it if it is not achieved. They have the confidence that they can do a lot. For this they study and research. By creating tools or writing and luxury they have an inclination of establish their identity. If they get a lot of money in this, these people spend a lot of money in new experiments research, and charity. These people are confident about their ability. That is why they have the hope to earn a lot of money a become rich.</p>";
        }            
if ($lucky_number == '8') {
        echo "<b>YOUR LUCKY NUMBER IS 8</b>
<p align=\"justify\">Number 8 represents the planet saturn. This number influences all persons born on the 8th, 17th or 26th of any month. They are talkative and boast at a lot. They cannot keep a secret for long and hence are not confidential. They believe in comforts. They have deep and very intense natures, great strength of individuality, they generally play some important role on life stage, but usually on which is fatalistic, or as the instrument of fate for others. They are handsome, smart, healthy and attractive but well wrapped with carelessness. It is advisable for them that they should not spoil their time in futile talks and curb their habit of carelessness if at all they do so they can be more successful. The lucky colours for people born under the number 8 are all shades of dark grey, black, dark blue and purple. If number 8 persons wear dress in light colours they would look awkward and as if there is something wrong with them.</p>
<b>Nature</b>
<p align=\"justify\">The number eight people are very emotional. They think deeply about everything they are basically just and upright. They always feel that all should get equal justice. It is observed that they have socialistic leanings. Even if their views are opposed they are very firm about them. This result in enmity with many people. Their sympathetic emotions are very different. They have great love for small children. They spend a lot of time and money for the pleasure and education of children. They do not express clearly their sympathy or others. These people firm about their emotions. Sometimes because of their not expressing their emotions people misunderstand them and find them mysterious. The number eight people are fanatically religious. Their views about their country, religion and politics are very clear. Many a times they behave with stern sense of justice. Even though their mentality is approved by others they find it impracticable. That is why common people do not talk with the number eight people freely. </p>";
        }            
if ($lucky_number == '9') {
        echo "<b>YOUR LUCKY NUMBER IS 9</b>
<p align=\"justify\">
Number 9 represent the planet Mars. This number influences all persons born on the 9th, 18th, and 27 of any months. They are short tempered, also very argumentative. Natives of this number are extremely optimistic. Everything they believe, is possible under the sun. They keep on trying untill they succeed. They have great courage and make excellent soldiers or leaders in any cause they espouse. They are excellent in organisation, but they must have the fullest control. if not they lose heart and stand aside and let things go to peaces. They easily pass through odd curcumstances. They hardly get any support from their family side but it does not deviate them from their path. They never lose heart. Machinery, job of manager, research etc. are their fields of interest.
</p>
The lucky colours for persons born under the number 9 are all shades of crimson red also all rose tones and pinks. Their most important days in the week are Tuesday, Thursday and friday but more especially Tuesday.

<b>Nature</b>

<p align=\"justify\">
Boldness, inspiration, moral strength, capacity to take quick decisions, irresistible nature are the main qualities observed in these people. Intuition, inner urge energy for work & resistance power are the stock of valuable assets given to these people by the nature. In difficult times it is observed that these people get intution to danger which is approaching. The quality of endangering their lives to save that of other is their natural instinct. Number nine people are very ambitious. They do not like delaying any work. With split second decisions they complete the work. The number nine people can be easily recognized by their personally. Straight nose, broad nostrils, while talking attack the opposite person, sharp eye and the opening language that the opposite person should hear him are the characteristics of number nine. These people do not like any opposition they quickly get excited and cool down quickly. As these people have a great presence of mind others have regards for them .</p>";
        }            
?>


<?php
$table_name="swdata";
$verbose=1;
scraperwiki::save_sqlite(array("a"),array("a"=>1, "bbb"=>"Hi there"), $table_name, $verbose);

?>

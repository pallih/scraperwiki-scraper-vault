import scraperwiki
from scraperwiki.sqlite import save

data = {
    "firstname": "Tom", 
    "lastname":  "Levine"
}

save([], data)

# Blank Python


<?php
$html = scraperWiki::scrape("http://flipkart.com");
 print $html . "\n";
//require 'scraperwiki/simple_html_dom.php';


?>

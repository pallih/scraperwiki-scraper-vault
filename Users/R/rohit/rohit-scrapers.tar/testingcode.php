<?php

$str1="1,405  1,264 (10% OFF) &nbsp;&nbsp;";
$str2="13 new & used from sellers starting at </span> 665 &nbsp;&nbsp;";
$str3="jklfhghgjdhljk";
$r=explode(" ",$str3);
echo count($r);

echo "sorry";




?>

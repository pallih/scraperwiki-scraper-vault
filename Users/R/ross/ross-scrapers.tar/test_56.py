# Blank Python


print ';s'
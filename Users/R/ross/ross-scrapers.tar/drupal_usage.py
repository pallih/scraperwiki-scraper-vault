import lxml
import scraperwiki

# Blank Python

html = scraperwiki.scrape('http://drupal.org/project/usage')

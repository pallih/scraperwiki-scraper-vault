# A simple scraper that exercises the scraperwiki api for testing purposes


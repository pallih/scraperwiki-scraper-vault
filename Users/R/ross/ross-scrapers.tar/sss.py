from scraperwiki import swimport
swimport('eb').scrape('http://jdcny.eventbrite.com/')
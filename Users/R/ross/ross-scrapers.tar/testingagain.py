import scraperwiki

# Blank Python

print 's'
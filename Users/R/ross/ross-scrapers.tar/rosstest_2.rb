# Blank Ruby


ScraperWiki.save_var("INDEX", 20)
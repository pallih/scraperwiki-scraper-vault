# Blank Python
import scraperwiki
scraperwiki.sqlite.save('x', {'': ''} )
print scraperwiki.sqlite.table_info('swdata')
#scraperwiki.sqlite.select('* from swdata')
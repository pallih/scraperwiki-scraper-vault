# Blank Ruby

puts ScraperWiki.scrape('https://views.scraperwiki.com/run/uk_postcode_lookup/?postcode=ch649pp')
puts ScraperWiki.gb_postcode_to_latlng("ch649pp")


# Blank Ruby


ScraperWiki.save_sqlite(['id'], {'id' => 00230, 'test' => 'title'})
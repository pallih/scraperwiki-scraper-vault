# Blank Python
print x + =
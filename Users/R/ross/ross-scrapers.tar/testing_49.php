<?php

//require 'scraperwiki/simple_html_dom.php'; 

$record = array("country"=>"UK", "value"=>"Test");
scraperwiki::save(array('country'), $record);    

?>

# Blank Ruby


s = Time.now

ScraperWiki.save_sqlite(['id'], {'id'=>1, 'doc' => s })

# Blank Python
print 's'
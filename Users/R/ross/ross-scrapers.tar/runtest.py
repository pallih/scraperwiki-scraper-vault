import scraperwiki

# Blank Python

scraperwiki.sqlite.save(['id'], {'id': 1})
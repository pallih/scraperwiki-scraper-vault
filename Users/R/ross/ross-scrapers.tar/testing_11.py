import scraperwiki
print 's'

scraperwiki.sqlite.save(['id'], {'id': 1234})
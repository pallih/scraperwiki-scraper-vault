# Blank Ruby

x = ScraperWiki.get_var("OFFSET",5)
puts x
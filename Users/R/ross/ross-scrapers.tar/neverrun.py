import scraperwiki

# Blank Python

print 'Never run'
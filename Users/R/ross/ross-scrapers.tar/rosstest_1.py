# Blank Python
 

import scraperwiki

scraperwiki.sqlite.save_var('test',1)
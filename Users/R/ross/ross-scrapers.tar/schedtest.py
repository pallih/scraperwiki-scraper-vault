import scraperwiki

# Blank Python

print 'Hello!'
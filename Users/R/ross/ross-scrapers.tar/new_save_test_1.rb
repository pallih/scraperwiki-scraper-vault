# Blank Ruby

  ScraperWiki.save_sqlite(unique_keys=['title'], data={'title'=>'test'},table_name='swdata')
import os,sys, scraperwiki

# Blank Python


f = open( os.path.join(os.getcwd(), 'test.txt'), 'w' )
print os.listdir(os.getcwd())
f.close()

f = open( '/usr/local/bin/test.txt', 'w' )
f.close()
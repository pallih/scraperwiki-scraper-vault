import scraperwiki
scraperwiki.utils.httpresponseheader("Content-Type", "text/json")
print '{"test":1}'
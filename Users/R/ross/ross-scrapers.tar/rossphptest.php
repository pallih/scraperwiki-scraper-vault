<?php

# Blank PHP

print "Hello"
?>

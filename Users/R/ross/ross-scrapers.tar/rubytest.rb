# Blank Ruby

begin
  html = ScraperWiki.scrape('http://morty.co.uk/sleep.php')
  puts html
rescue Timeout::Error
  puts 'Timed out'  
end
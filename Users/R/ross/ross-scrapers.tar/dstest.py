import scraperwiki

# Blank Python

scraperwiki.sqlite.save(['id'], {'id':1, 'nun':None, 'num': 1325675474.1173401})
scraperwiki.sqlite.save(['id'], {'id':2, 'nun':'x', 'num': 1325675474.1173401})

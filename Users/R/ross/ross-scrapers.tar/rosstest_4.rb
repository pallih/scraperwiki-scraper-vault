# Blank Ruby
 

ScraperWiki.save_sqlite(['SCRAPED_NUMBER'], {'SCRAPED_NUMBER' => 1, 
'ENTITY_NUMBER' => '', 'ENTITY_NAME' => '', 'STATUS' => '', 'ENTITY_TYPE' =>'', 'URL' => '', 'DOC' => '','DOF' => '', 'ENTITY_STATUS' => '', 'TYPE' => ''});

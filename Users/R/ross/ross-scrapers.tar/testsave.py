import scraperwiki

scraperwiki.sqlite.save('title', {'title': 'a'})
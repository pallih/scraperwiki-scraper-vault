# Blank Python
# Blank Python
import scraperwiki
record = {
    'id': 0,
    'test_broken': 'somevalue',
}
scraperwiki.datastore.save([u"id"], record)
scraperwiki.datastore.save([u"id"], record,table_name='new test table name')
scraperwiki.datastore.save([u"id"], record,table_name='a new test')
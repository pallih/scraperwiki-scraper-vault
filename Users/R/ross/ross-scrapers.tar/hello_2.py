import scraperwiki

scraperwiki.sqlite.save(['id'], {'id':1})
# Blank Python
import scraperwiki

scraperwiki.scrape('http://www.pla.co.uk')

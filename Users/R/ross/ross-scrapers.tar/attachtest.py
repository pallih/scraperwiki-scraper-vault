import os
import scraperwiki
import timeit


def save():
    try:
        scraperwiki.sqlite.attach('bcsh_guidlines')
        scraperwiki.sqlite.save(['id'], {'id':1})
        scraperwiki.sqlite.execute('select * from bcsh_guidlines.swdata')
    except:
        pass

#print 'hello'
save()
save()

#print timeit.timeit(save, number=50)


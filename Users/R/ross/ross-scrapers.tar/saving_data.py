# Blank Python
sourcescraper = ''
import scraperwiki

#scraperwiki.sqlite.save(['id'], {'id': 3} )

print scraperwiki.sqlite.select('* from swdata')
 
Accountancy 135 89% 47% 7.4 
Advanced Sensor Applications 29 - - 7.8 
Autonome Beeldende Kunst 45 65% 59% 7.5 
Bedrijfseconomie 276 88% 50% 7.5 
Bedrijfskunde MER 197 78% 51% 6.9 
Bio-informatica 34 - 38% 7.9 
Biologie en Medisch Laboratoriumonderzoek 130 90% 52% 7.8 
Bouwkunde 170 76% 55% 6.9 
Business IT & Management 39 93% 59% 7.5 
Chemie 48 78% 40% 7.4 
Chemische Technologie 33 92% 55% 7.5 
Civiele Techniek 51 88% 56% 7.4 
Commerciele Economie 284 80% 49% 7 
Communicatie 324 76% 47% 7 
Communicatiesystemen 198 87% 39% 7.1 
Dans (A'dam) 18 59% 49% 7.8 
Dans (Groningen) 11 59% 49% 8 
Docent Beeldende Kunst en Vormgeving 24 75% 83% 7.5 
Docent Dans (A'dam) 8 - 78% - 
Docent Dans (Groningen) 8 - 78% 7.9 
Docent Muziek 12 90% 71% 7.9 
Elektrotechniek 52 91% 57% 7.5 
Facility Management 293 73% 66% 7.2 
Financial Services Management 69 75% 31% 7.5 
Fiscaal Recht en Economie 35 92% 56% 7.5 
HBO - Rechten 304 66% 42% 7.3 
Human Resource Management 164 72% 58% 7.3 
Human Technology 52 60% 44% 7 
Informatica 89 93% 49% 7.4 
Informatiedienstverlening en -management 22 82% 51% 7.1 
International Business and Languages 96 78% 38% 7.3 
International Business and Management Studies 522 86% 57% 7.3 
Lerarenopleiding eerste graad Lichamelijke Oefening 242 86% 50% 7.4 
Lerarenopleiding Basisonderwijs 275 92% 65% 6.9 
Maatschappelijk Werk en Dienstverlening 220 64% 54% 7.2 
Medisch Beeldvormende en Radiotherapeutische Technieken 138 95% 66% 7.9 
Mondzorgkunde 55 99% 55% 7.3 
Muziek (Groningen) 53 71% 47% 7.7 
Muziek (Popacademie L'warden) 43 71% 47% 7.2 
Opleiding tot Fysiotherapeut 280 96% 69% 7.6 
Opleiding tot Verpleegkundige 419 60% 70% 6.9 
Opleiding voor Logopedie 109 92% 68% 7.2 
Small Business en Retail Management 129 74% 39% 7.1 
Sociaal Pedagogische Hulpverlening 275 48% 58% 7.3 
Sociaal-Juridische Dienstverlening 213 66% 54% 7.4 
Sport, Gezondheid en Management 211 63% 47% 7.3 
Technische Bedrijfskunde 143 87% 51% 7.3 
Technische Informatica 38 95% 53% 7.4 
Toegepaste Psychologie 194 - - 7.5 
Vastgoed en Makelaardij 172 79% 42% 7.3 
Voeding en Diëtetiek 169 86% 62% 7.3 
Vormgeving (Groningen) 80 73% 58% 7.3 
Vormgeving (Popacademie Leeuwarden) 12 73% 58% 7.4 
Werktuigbouwkunde 127 92% 58% 7.5 




 

Naar boven 
 

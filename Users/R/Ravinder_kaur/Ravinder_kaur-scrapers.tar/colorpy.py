# Blank Python
import turtle
turtle.color('red')
turtle.circle(-25)
turtle.up()
turtle.color('yellow')
turtle.circle(30)
turtle.goto(0,120)
turtle.down()
turtle.color('green')
turtle.circle(30)

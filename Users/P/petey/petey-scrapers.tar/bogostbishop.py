import scraperwiki

from scraperwiki import swimport

search = swimport('twitter_search').search
search(['from:ibogost'])

#print search




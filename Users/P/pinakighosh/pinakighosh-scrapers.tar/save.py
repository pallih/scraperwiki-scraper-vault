import scraperwiki

query='"sl_no":2,"Number_of_primary_schools":"713","Unirrigated_Area":"21984.80","Area_not_available_for_cultivation":"10,041.82","River_water":"","Number_of_maternity_home":"0","Number_of_ayurvedic_dispensary":"0","Number_of_primary_health_centre":"31","Number_of_middle_schools":"199","Number_of_family_welfare_centre":"61","Number_of_telegraph_office":"1"'
#scraperwiki.sqlite.save(unique_keys=["sl_no"],data={query})
scraperwiki.sqlite.save(unique_keys=["sl_no"],data={"sl_no":2,"Number_of_primary_schools":"713","Unirrigated_Area":"21984.80","Area_not_available_for_cultivation":"10,041.82","River_water":"","Number_of_maternity_home":"0","Number_of_ayurvedic_dispensary":"0","Number_of_primary_health_centre":"31","Number_of_middle_schools":"199","Number_of_family_welfare_centre":"61","Number_of_telegraph_office":"1"})

import scraperwiki

# Blank Python
#example scraper
# https://scraperwiki.com/scrapers/swutils/
#blog post - twitter example
#http://blog.scraperwiki.com/2011/10/19/tweeting-the-drilling/

<?php
# Blank PHP


$sourcescraper = 'bbc_news_by_country_or_location';



//$keys = scraperwiki::getKeys($sourcescraper); 



//$sourcescraper = bbc_news_by_country_or_location;
scraperwiki::attach("locations");   
print "hello world";
print $keys;
print "and...";
print_r(scraperwiki::show_tables()); 
?>

# Blank Ruby
puts 1
puts "hello world"
puts 1+2
puts 3*7
puts "luis" + "martinez"
puts "luis".gsub("l","L")
puts "luis"[0..2]
puts "luis"*3

s="Hello world" 
puts s

$ciudad="Madrid"
puts $ciudad

$value=0

if $value==0 then
 puts "value is zero. Did you guess that one?"
else
puts "value is not zero"
 end

for i in 1..5
puts 1
end

names = ['Ada', 'Belle', 'Chris']
puts names
puts names[0]
puts names[4]

capitales={}
capitales["Inglaterra"]="londres"
capitales["Spain"]="Madrid"

puts capitales["Spain"]

import scraperwiki

# http://www.sykehuset-ostfold.no/pasient/pasientsikkerhet/3-3-meldinger-om-uonskede-hendelser/Sider/side.aspx
# http://www.dagbladet.no/2012/09/16/nyheter/ahus/innenriks/sykehus/helse/23430439/
# http://www.ahus.no/fagfolk/temasider/Sider/3-3-meldinger-om-uonskede-hendelser-.aspx

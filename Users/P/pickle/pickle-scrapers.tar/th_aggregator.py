import scraperwiki
import lxml.html
import urllib
import re

mainURL = "http://www.thehindu.com/navigation/?type=rss"

def main():
    root = lxml.html.fromstring(mainURL)    
    

#call main function
main()
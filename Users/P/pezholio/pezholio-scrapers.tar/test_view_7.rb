# Blank Ruby
puts params
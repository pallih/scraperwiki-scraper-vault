# Blank Ruby

anvar = "1234"

var = 'my name is ' + anvar

puts var




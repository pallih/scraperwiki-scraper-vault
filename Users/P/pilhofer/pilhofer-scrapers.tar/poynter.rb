# Blank Ruby

#https://scraperwiki.com/scrapers/new/ruby?template=ruby-tutorial-2
#https://scraperwiki.com/scrapers/new/ruby?template=advanced-scraping-csv-files-1
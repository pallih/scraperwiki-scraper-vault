import scraperwiki
import pdftoxml

#http://www.birmingham.gov.uk/cs/Satellite/primaryschool?packedargs=website%3D4&rendermode=l
# This grabs the PDF and uses pdftoxml to convert

pdfurl = "http://www.birmingham.gov.uk/cs/Satellite?blobcol=urldata&blobheader=application%2Fpdf&blobheadername1=Content-Disposition&blobkey=id&blobtable=MungoBlobs&blobwhere=1223519452687&ssbinary=true&blobheadervalue1=attachment%3B+filename%3D995924PrimaryEducationBklt121129.pdf"

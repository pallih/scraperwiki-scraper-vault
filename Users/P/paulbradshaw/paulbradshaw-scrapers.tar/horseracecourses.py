import scraperwiki
import urlparse
import lxml.html

# scrape_table function: gets passed an individual page to scrape
def scrape_table(root):
    rows = root.cssselect("table tr")  # selects all <tr> blocks 
    for row in rows:
        # Set up our data record - we'll need it later
        record = {}
        table_cells = row.cssselect("td")
        if table_cells: 
            record['Course'] = table_cells[0].text_content()
            record['Address'] = table_cells[1].text
            record['URL'] = table_cells[2].text
            # Print out the data we've gathered
            print record, '------------'
            # Finally, save the record to the datastore - 'Artist' is our unique key
            scraperwiki.datastore.save(["Course"], record)
        
# scrape_and_look_for_next_link function: calls the scrape_table
# function, then hunts for a 'next' link: if one is found, calls itself again
def scrape_and_look_for_next_link(url):
    html = scraperwiki.scrape(url)
    print html
    root = lxml.html.fromstring(html)
    scrape_table(root)

# ---------------------------------------------------------------------------
# START HERE: define starting URL - then run function on it
# ---------------------------------------------------------------------------
starting_url = 'http://www.ukjockey.com/maps.html'
scrape_and_look_for_next_link(starting_url)

import scraperwiki
html = scraperwiki.scrape("http://pretraga2.apr.gov.rs/EnterprisePublicSearch/details/EnterpriseBusinessName/1335330?code=620B52581BD2D831C00E2A0D0DC04739C1C3B6FB")
print html
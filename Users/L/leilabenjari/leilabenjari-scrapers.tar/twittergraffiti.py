import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['graffiti OR streetart'], num_pages=20)
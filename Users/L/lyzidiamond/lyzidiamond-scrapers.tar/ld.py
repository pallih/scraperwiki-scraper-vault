import scraperwiki

x = 'sad'

print x

# Blank Python


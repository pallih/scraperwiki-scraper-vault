import scraperwiki

# Blank Python
parent_id=25047 #hartlepool unitary authority
parent_id=25014 #middlesbrough council
parent_id=25588 #redcar and cleveland council
parent_id=25587 #stockton council
import scraperwiki
import simplejson
import urllib2
import sys

# API help:https://dev.twitter.com/docs/api/1.1/get/search/tweets
url='https://dev.twitter.com/docs/api/1.1/get/search/tweets'

url.search('"#nyfw” + “since:2012-09-10″')

# iterate through each of the tweets, + print its contents 



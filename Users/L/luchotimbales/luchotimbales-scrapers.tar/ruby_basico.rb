# Ruby basico

# Comando puts para sacar información por pantalla

puts 1
puts "hello world"

# Numeros y su aritmetica

puts 1+2 
puts 3*7

# Strings y su aritmetica

puts "luis"
puts "luis" + " martinez"
puts "luis".gsub("l","L")
puts "luis"[0..2]
puts "luis" *3

# Variables (locales)
s = 'Hello World!' 
puts s
x = 10
puts x

# Variables (globales)

$contador=100
puts $contador

$ciudad="Madrid"
puts $ciudad

# Conditional statement "IF"

$value=0
if $value==0 then
     puts "value is zero. Did you guess that one? "
else
     puts "value is not zero"
end

# Loops "FOR"

for i in 1..5
    puts i 
end

# Arrays

names = ['Ada', 'Belle', 'Chris'] 

puts names 
puts names[0] 
puts names[1] 
puts names[2] 
puts names[3] # This is out of range.
puts names.length
puts names.first
puts names.last

capitales={}
capitales["Inglaterra"]="Londres"
capitales["Australia"]="Camberra"
puts capitales
puts capitales["Inglaterra"]
puts capitales["Australia"]


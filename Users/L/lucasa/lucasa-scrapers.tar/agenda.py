import scraperwiki
data = "31/05/2011"
html = scraperwiki.scrape("http://www.queb.com.br/agenda.php?tp=6&dt="+data)
print html
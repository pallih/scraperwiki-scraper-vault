from nltk import pos_tag, word_tokenize
import nltk
help(nltk.parse)

import nltk
import nltk.book

#nltk.stem.porter.demo()
#nltk.stem.lancaster.demo()

print word_tokenize("""Ross said, "Where's my coffee", because he wants to know who is putting the coffee on.""") 
<?php
# Blank PHP
$sourcescraper = 'irish_president_engagementsjson';
print $sourcescraper;
$s = scraperwiki::attach($sourcescraper, $limit=250);
header('Content-type: application/json');
print "{ \"items\": ".json_encode($s) ."}";


?>

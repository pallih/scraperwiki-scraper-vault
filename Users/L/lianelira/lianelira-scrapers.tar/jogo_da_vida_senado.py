import scraperwiki
from lxml.html import parse
import re

url = 'http://www.senado.gov.br/atividade/Materia/consulta.asp?Tipo_Cons=8&orderby=6&hid_comissao=TOD+-+TODAS&hid_status=TOD+-+TODAS&str_tipo=PLC&selAtivo=&selInativo=&radAtivo=S&txt_num=41&txt_ano=2010&sel_tipo_norma=&txt_num_norma=&txt_ano_norma=&sel_tipo_autor=&txt_autor=&sel_partido=&sel_uf=&txt_relator=&ind_relator_atual=S&sel_comissao=&txt_assunto=&tip_palavra_chave=T&rad_trmt=T&sel_situacao=&ind_status_atual=A&dat_situacao_de=&dat_situacao_ate=&txt_tramitacao=&dat_apresentacao_de=&dat_apresentacao_ate='

    data = {}
    #data[id_pl] = 

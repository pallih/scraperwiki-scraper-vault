import scraperwiki
from lxml.html import parse
import urllib



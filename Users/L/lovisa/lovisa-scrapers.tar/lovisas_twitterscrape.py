import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['koko'], num_pages=5)



# Blank Ruby
puts 1
puts "hello world"

puts 1+2
puts 3*7

puts "luis" + "martinez" 
puts "luis".gsub("l","L")
puts "luis"[0..2]
puts "luis"*3

s="Hello World"
puts s

$ciudad="Madrid"
puts $ciudad

$value=10

if $value==0 then puts "value is zero. Did you guess that one?"
else puts "value is not zero" 
end

for i in 1..5 
puts i 
end

names=['Ada','Belle','Chris']
puts names
puts names[0]
puts names[1]
puts names[2]
puts names[3] #This is out of range.
puts names.length

capitales={}
capitales["Inglaterra"]="londres"
capitales["Spain"]="madrid"

puts capitales "Spain"




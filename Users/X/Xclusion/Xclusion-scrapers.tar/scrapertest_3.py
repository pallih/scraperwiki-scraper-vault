#!/usr/bin/python
# -*- coding: latin-1 -*-

from mechanize import Browser
from BeautifulSoup import BeautifulSoup

import scraperwiki
from scraperwiki import sqlite
import re
import numpy 
import csv   
import datetime
import time


crap = unicode(1.2)
print(11.1+float(crap))

import scraperwiki

# Blank Python

for i in range(1,15):
 scraperwiki.sqlite.save(['url'],data={'url':'http://www.indiaplaza.com/laptops-pc-1.htm?sort=dp&PageNo='+str(i)})
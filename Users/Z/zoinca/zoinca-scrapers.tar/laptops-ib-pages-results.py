import scraperwiki

# Blank Python

for i in range(1,11):
 scraperwiki.sqlite.save(['url'],data={'url':'http://www.infibeam.com/Laptop_Computers_Accessories/#category=Laptop&store=Computers_Accessories&page='+str(i)})

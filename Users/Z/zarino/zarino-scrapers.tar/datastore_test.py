import scraperwiki

print scraperwiki.sqlite.save(['a'], {'a':'foobar', 'b':'barfoo'})

print scraperwiki.sqlite.select('* from swdata')
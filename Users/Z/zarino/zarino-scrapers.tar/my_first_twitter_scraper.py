import scraperwiki

search = scraperwiki.swimport('instagram_search_extended').search

search(['graffiti'], num_pages=50)
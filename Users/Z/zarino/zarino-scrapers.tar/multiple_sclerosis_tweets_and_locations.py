from scraperwiki import swimport 

swimport('twitter_search_extended').search(['multiple sclerosis'], num_pages = 100)
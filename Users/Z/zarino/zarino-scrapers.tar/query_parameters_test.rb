require 'cgi'           
param_dict = CGI::parse( ENV['QUERY_STRING'] )
<?php

print_r($_GET);

print_r($_SERVER);

//parse_str($_ENV["QUERY_STRING"], $output);           
//print_r($output);

?>

import scraperwiki
import urlparse
import urllib, urllib2
import lxml.html
import lxml.etree
import mechanize
import time
import sys, time, os
from mechanize import Browser

localtime = time.asctime( time.localtime(time.time()) )
print "Local current time :", localtime


<?php

echo phpinfo();
?>

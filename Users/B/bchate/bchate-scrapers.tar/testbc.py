import scraperwiki
html = scraperwiki.scrape('https://scraperwiki.com/hello_world.html')
print html
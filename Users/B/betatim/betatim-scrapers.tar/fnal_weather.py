import scraperwiki

# Blank Python

base_url = "http://www-esh.fnal.gov/pls/default/weather.month?this_year=%i&this_month=%01i"
import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search (['glad'], num_pages=5)



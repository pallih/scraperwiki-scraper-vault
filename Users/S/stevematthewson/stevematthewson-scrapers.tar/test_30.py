print "Hello, coding in the cloud!" 
import scraperwiki html = scraperwiki.scrape("http://unstats.un.org/unsd/demographic/products/socind/education.htm") print html 

# Blank Ruby
puts "hello world"

<?php

$m = scraperwiki::save(array("id"),array("id"=>3, "wibro1m" => 3.23, "wibor3m"=>4.4433));
#print_r($m);
?>

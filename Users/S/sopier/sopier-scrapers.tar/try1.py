import scraperwiki
import re

#html = scraperwiki.scrape('http://www.google.com/search?q=python', user_agent='Mozilla')
#print html

#print re.search(re.compile(r"\d"), "satu 12").group()
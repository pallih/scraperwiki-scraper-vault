<?php
# Blank PHP
$sourcescraper = 'ons_release_schedule_ical';

Print "$icalstring";
?>

# Bash Demo
# David Jones, Climate Code Foundation

import os
import urllib

# Load an image for scraper's icon on ScraperWiki.
urllib.urlopen("http://a1.mzstatic.com/us/r1000/034/Purple/07/48/b9/mzl.miktnepx.175x175-75.jpg").read()

script = """
cat /etc/*-release
apt-get install python-webkitgtk libwebkit-1.0-1 libwebkit-dev
"""
#
with open('script.sh', 'w') as f:
    f.write(script)

os.system("bash script.sh")


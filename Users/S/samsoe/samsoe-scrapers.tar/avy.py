import scraperwiki
html = scraperwiki.scrape("http://www.wcc.nrcs.usda.gov/snotel/Montana/montana.html")
print html


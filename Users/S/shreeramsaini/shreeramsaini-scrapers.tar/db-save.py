import scraperwiki

# Blank Python

scraperwiki.sqlite.save(['url'],data={'url':'www.flipkart.com1','pid':'p1'})
scraperwiki.sqlite.save(['url'],data={'url':'www.flipkart.com2','pid':'p2'})
scraperwiki.sqlite.save(['url'],data={'url':'www.flipkart.com3','pid':'p3'})

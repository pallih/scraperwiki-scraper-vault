import scraperwiki

scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:0/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:24/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:48/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:72/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:96/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:120/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:144/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:168/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:192/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:216/inStock:true/'})
scraperwiki.sqlite.save(['url'],data={'url':'http://www.homeshop18.com/laptops/categoryid:3291/search:*/sort:Best+Sellers/start:240/inStock:true/'})
  


import scraperwiki

i=0
while i<=3:
 j= "%s%d%s" % ('mohan',23,'kk')
 print j
 i=i+1



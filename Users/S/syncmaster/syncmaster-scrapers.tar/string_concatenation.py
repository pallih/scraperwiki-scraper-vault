import scraperwiki

# Blank Python
str1 = 'Also known as <a href="http://www.twitter.com/pwapn" target="_blank">@PWAPN</a> on Twitter, we bring together professionals in over 30+ industries providing products, services and solutions for Public Works and Infrastructure.'
str2 = "hello"
str3 = str1 + str2


<?php

# Blank PHP
$html = scraperWiki::scrape("http://www.thomasnet.com/products/plastic-pipe-58530403-1.html?WTZO=Find%20Suppliers");
print $html . "\n";

?>

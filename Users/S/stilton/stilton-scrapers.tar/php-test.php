<?php

$lat_lng = scraperwiki::gb_postcode_to_latlng("SW1A 2AA");
print_r($lat_lng);
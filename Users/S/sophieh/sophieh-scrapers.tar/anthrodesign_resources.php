<?php

# Blank PHP
//https://docs.google.com/spreadsheet/pub?key=0AjaPH1oINIzwdHFQWWlaOU0zRGtoSmhCNGpKcTJ2R0E&single=true&gid=0&range=a1%3Ah45&output=html&widget=true
//https://docs.google.com/spreadsheet/pub?key=0AjaPH1oINIzwdHFQWWlaOU0zRGtoSmhCNGpKcTJ2R0E&chrome=false&gid=0


?>

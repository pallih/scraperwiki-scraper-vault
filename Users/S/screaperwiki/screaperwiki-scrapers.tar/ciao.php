<?php

for ($i=1;$i<=10000;$i++)
{
    file_get_contents("http://www.google.it");
}
?>

# Blank Python
# Used to check off a scraper I wrote somewhere else.
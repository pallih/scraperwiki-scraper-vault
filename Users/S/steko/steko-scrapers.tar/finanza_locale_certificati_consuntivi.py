# starturl = "http://finanzalocale.interno.it/sitophp/in.php?cod=4"

# basetemplate = "http://finanzalocale.interno.it/sitophp/home_cert.php?tipo_ente=CO&anno=2009&Nome_Ente=Torriglia&tipo_cert=C&tipoarea=C&cod=4"

# detailtemplate = "http://finanzalocale.interno.it/sitophp/showQuadro.php?codice=1070340620&tipo=CO&descr_ente=TORRIGLIA&anno=2009&cod_modello=CCOU&sigla=GE&tipo_cert=C&isEuro=0&quadro=01"


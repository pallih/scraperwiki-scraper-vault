print "<table border='2'>"
for i in range(10): 
    print "<tr>"
    print "<td>1</td>"
    print "<td>2</td>"
    print "</tr>"
print "</table>"

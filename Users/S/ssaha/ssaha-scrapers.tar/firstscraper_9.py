print "<table>"
print "<tr><th>Country</th><th>Years in school</th>"
for i in range(9):
    print "<tr>"
    print "<td>", 1, "</td>"
    print "<td>", 2, "</td>"
    print "</tr>"
print "</table>"

import scraperwiki

# Blank Python
#html=scraperwiki.scrape("http://smpbank.ru/ajax/gm/getBranchInfo",{'branchId':9})
html=scraperwiki.scrape("http://smpbank.ru/ajax/gm/branches")
print html

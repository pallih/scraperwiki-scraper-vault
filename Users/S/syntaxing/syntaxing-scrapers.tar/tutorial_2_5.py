import scraperwiki

print "This is a <em>fragment</em> of HTML."

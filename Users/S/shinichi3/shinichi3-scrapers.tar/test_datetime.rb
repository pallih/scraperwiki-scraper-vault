require 'date'

d = Date.today

puts d
puts d-1
# coding: utf-8

#require 'nokogiri'
#require 'open-uri'
#require 'uri'



#url = "http://ja.dbpedia.org/sparql?default-graph-uri=http://ja.dbpedia.org&query=SELECT+DISTINCT+*+WHERE+{+++?s+rdfs:label+\"東京\"+@ja++.+}&format=text/html&debug=on&timeout=&format=html"

#url2 = URI.encode(url)

#puts url
#puts url2

end
<?php

require 'scraperwiki/simple_html_dom.php';
scraperwiki::attach("Range1.swdata");


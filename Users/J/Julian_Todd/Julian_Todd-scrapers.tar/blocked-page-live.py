# throws the some weird socket error', gaierror error code, different to dev
import urllib
print "hi"
print urllib.urlopen("http://www.porn.com")

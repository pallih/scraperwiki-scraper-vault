import scraperwiki
import os

scraperwiki.utils.httpresponseheader("Content-Type", "text/plain")
print '<h1>Hi there</h1>'
print "The urlquery is:" + os.getenv("URLQUERY")


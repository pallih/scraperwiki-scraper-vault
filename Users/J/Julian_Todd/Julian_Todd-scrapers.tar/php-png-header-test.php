<?php
$url = "http://scraperwiki.com/media/images/intro_slides/intro4.png"; 
$curl = curl_init ($url ) ;
curl_setopt ($curl, CURLOPT_RETURNTRANSFER, true) ;
$data  = curl_exec ($curl) ;
curl_close ($curl) ;

    //print $data; 
$dict = array('message_type' => 'console', 'encoding' => "base64", 
                     'content' => base64_encode($data));
scraperwiki::httpresponseheader("Content-Type", "image/png");
scraperwiki::sw_dumpMessage ($dict); 
?>
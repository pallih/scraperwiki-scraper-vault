from scraperwiki.apiwrapper import getData

sourcescraper = "birmingham-council-500-spending"

limit = 2000  
offset = 0

companysums = { }
n = 0
for row in getData(sourcescraper, limit, offset):
    company = row["vendor"]
    if company not in companysums:
        companysums[company] = 0
    companysums[company] += float(row["amount"])
    n += 1
    
allv = companysums.items()
allv.sort(key=lambda x:x[1], reverse=True)

print "<h1>Top companies to do work for Birmingham (%s records)<h1>" % n
print '<table border="1">'

for a in allv[:50]:
    print "<tr><td>", a[0], "</td><td>", a[1], "</td></tr>"
print '</table>'
    


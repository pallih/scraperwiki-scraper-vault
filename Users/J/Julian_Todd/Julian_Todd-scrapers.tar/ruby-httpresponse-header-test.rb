ScraperWiki.httpresponseheader("Content-Type", "text/plain")
#ScraperWiki.httpresponseheader("Content-Type", "text/html")
puts "<h1>hi there</h1>\n"

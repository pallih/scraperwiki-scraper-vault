print "save 1"
print "save 2"
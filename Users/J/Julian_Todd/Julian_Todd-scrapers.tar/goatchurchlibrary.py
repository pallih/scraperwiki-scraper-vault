def GHGH():
    return "hihi"
    
import scraperwiki.metadata
scraperwiki.metadata.save("Hi", 999)
print scraperwiki.metadata.get('Hi')


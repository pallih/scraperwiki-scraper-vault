import scraperwiki
import urllib2

#url = 'http://www.electoralcommission.org.uk/__data/assets/excel_doc/0014/107006/candidate-returns-reduced.xls'
#url = 'http://tinyurl.com/2wk7srh'
#url = 'http://www.goatchurch.org.uk/ctrips/kayamediate/divekimya.jpg'
#url = 'http://www.undemocracy.com/A-62-PV.4.pdf'
url = 'http://ukpolitics.telegraph.co.uk/Bristol+East/Kerry+McCarthy'

scraperwiki.cache(False)
c1 = urllib2.urlopen(url).read()
print len(c1)
print c1
scraperwiki.cache(True)
c2 = urllib2.urlopen(url).read()
print len(c2)
print c2
print len(c1), len(c2)


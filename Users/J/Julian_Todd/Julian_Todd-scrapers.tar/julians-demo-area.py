import re
line = "*fix 7 7 7 ; some comment"

m = re.match("(.*);(.*)", line)
print m.groups()

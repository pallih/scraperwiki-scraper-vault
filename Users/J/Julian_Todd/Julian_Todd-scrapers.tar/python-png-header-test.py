import scraperwiki
import urllib
import base64

scraperwiki.utils.httpresponseheader("Content-Type", "image/PNG")
url = 'http://scraperwiki.com/media/images/intro_slides/intro4.png'
pngbin = urllib.urlopen(url).read()
scraperwiki.dumpMessage({"content":base64.encodestring(pngbin), "message_type":"console", "encoding":"base64"})



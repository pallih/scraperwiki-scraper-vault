<?php
    scraperwiki::httpresponseheader('Content-Type', 'text/plain');
    //scraperwiki::httpresponseheader('Content-Type', 'text/html');
    print "<h1>hi there</h1>\n";
?>
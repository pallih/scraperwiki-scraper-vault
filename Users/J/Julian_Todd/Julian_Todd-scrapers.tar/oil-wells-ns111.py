import scraperwiki
import re
import urllib2

# comments about a few sources.  This should be in several different scrapers

# Norway makes its oil wells data easily accessible:  hello james
# Hi Julian...
# license data: http://www.npd.no/engelsk/cwi/pbl/en/pl/all/212.htm
# well data http://www.npd.no/engelsk/cwi/pbl/en/well/all/6167.htm
print scraperwiki.scrape("http://www.npd.no/engelsk/cwi/pbl/en/pl/all/212.htm")
print "aha"

# uk data can be seen here:
#  https://www.og.decc.gov.uk/information/info_strategy/index.htm

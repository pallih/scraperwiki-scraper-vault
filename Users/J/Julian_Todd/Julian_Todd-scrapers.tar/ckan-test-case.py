import scraperwiki

#############################################################################################
# this executes an import from the code at http://scraperwiki.com/scrapers/ckanclient/edit/
# In the future there may be a slick way to overload __import__, but this does the job for now
ckanclient = scraperwiki.utils.swimport('ckanclient')


# example code copied from the documentation
my_key = "I don't have no key"
ckan = ckanclient.CkanClient(api_key=my_key)
package_list = ckan.package_register_get()
print package_list

# Get the tag list.
tag_list = ckan.tag_register_get()
print tag_list


require 'scraperwiki'
       

name1 = "uk-offshore-oil-wells"

# this comes out as a list
puts ScraperWiki.getKeys(name1)

# this comes as a generator.  Need someone who understands to sort this out.  Code copied off a website somewhere.
ScraperWiki.getData(name1, 150) {|i| puts "You are in the block #{i}"}


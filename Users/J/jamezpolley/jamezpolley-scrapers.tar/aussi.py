import scraperwiki

# Blank Python

##url: http://portal.aussi.org.au/results/results.php?year=----&name=NICHOLAS+PIRIE&aussiid=&pb=yes&sort=agegrp&Show=Show&js=on
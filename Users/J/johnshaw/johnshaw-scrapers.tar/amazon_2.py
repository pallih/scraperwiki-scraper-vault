import scraperwiki

# Blank Python

https://scraperwiki.com/scrapers/competitorsmonitor/ 
import scraperwiki
import gdata.youtube
import gdata.youtube.service
yt_service = gdata.youtube.service.YouTubeService()

# The YouTube API does not currently support HTTPS/SSL access. yt_service.ssl = False 
yt_service.developer_key = 'ABCxyz123...'
yt_service.client_id = 'My-Client_id'

import scraperwiki
scraperwiki.sqlite.attach("")
scraperwiki.sqlite.attach("")

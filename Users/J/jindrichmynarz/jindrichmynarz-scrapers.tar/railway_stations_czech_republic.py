import scraperwiki

# Blank Python

def download(uri):
  

def main():
  scraperwiki.sqlite.attach("railway_stations_czech_republic")
  baseURI = "http://www.cd.cz/cd-online/staniceinfo.php?nazev="
  range = [1, 99999]
  map(range, lambda no: download(baseURI + str(no)))


id = "hlprijmeni"
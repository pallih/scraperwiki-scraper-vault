import scraperwiki

# Blank Python

result>
<postcode>LS3 1AP</postcode>
<geo>
<lat>53.801788</lat>
<lng>-1.558618</lng>
<easting>429167</easting>
<northing>434033</northing>
<geohash>http://geohash.org/gcwfhd341s4n</geohash>
</geo>
<administrative>
<constituency>
<title>Leeds Central</title>
<uri>
http://data.ordnancesurvey.co.uk/doc/7000000000024804
</uri>
<code>24804</code>
</constituency>
<district>
<title>Leeds</title>
<uri>
http://statistics.data.gov.uk/id/local-authority/00DA
</uri>
<snac>00DA</snac>
</district>
<ward>
<title>Hyde Park and Woodhouse</title>
<uri>
http://statistics.data.gov.uk/id/electoral-ward/00DAHF
</uri>
<snac>00DAHF</snac>
</ward>
</administrative>
</result>
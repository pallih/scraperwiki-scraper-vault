# Blank Python

import scraperwiki           
html = scraperwiki.scrape("http://www.changedetection.com/accountfeed.xml?feedid=490465550510443")
print html
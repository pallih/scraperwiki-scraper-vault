<?php

$html = scraperWiki::scrape("https://play.google.com/apps/publish/Home?dev_acc=04952289883486156280#StatsPlace:p=com.simon.app.simonmalls");
print $html . "\n";

?>

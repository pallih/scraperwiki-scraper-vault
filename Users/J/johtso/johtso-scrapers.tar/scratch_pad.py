from lxml import etree
print etree.LXML_VERSION
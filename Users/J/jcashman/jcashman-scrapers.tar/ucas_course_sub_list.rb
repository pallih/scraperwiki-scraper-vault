import json

import lxml.html
import re
import urllib
import json

index = 'http://www.ucas.com/students/choosingcourses/choosinguni/instguide/'
letters = ['a']

print 'Checking which letters to scrape...'

#html = scraperwiki.scrape(index)

#root = lxml.html.fromstring(html)







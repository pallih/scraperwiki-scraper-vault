import scraperwiki

# Blank Python

print "Hello, coding in the cloud!"
import scraperwiki
import lxml.html

gasp_helper = scraperwiki.utils.swimport("gasp_helper")
gasp = gasp_helper.GaspHelper("ce429200f22a42c68bdf8bfa611bd085", "C001037")

html = scraperwiki.scrape("http://www.house.gov/capuano/")



gasp.finish()
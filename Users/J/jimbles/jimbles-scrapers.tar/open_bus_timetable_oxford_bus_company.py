import scraperwiki
import urllib2

#http://www.oxfordbus.co.uk/main.php?page_id=21
url = "http://www.oxfordbus.co.uk/content/doc/cms/city2_Web.pdf"


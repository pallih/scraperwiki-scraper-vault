# simple for-loop
for i in range(10):
    print "Hello", i
    #http://www.merseyfire.gov.uk/aspx/pages/community/fs-allerton.aspx
    {"aigburth-mossley-hill": ["fs-allerton.aspx1"],
     "allerton": ["fs-allerton.aspx"],
     "anfield-walton": ["fs-kirkdale.aspx"],
     "childwall-netherley": ["fs-belleVale.aspx"],
     "croxteth-fazakerley": ["fs-croxteth.aspx"],
     "halewood": ["fs-spekeGarston.aspx"],
     "huyton-prescot": ["fs-huyton.aspx"],
     "kirkby": ["fs-kirkby.aspx"],
     "speke-garston": ["fs-spekeGarston.aspx"],
     "st-helens": ["fs-stHelens.aspx"],
     "toxteth-wavertree": ["fs-toxteth.aspx"],
     "west-derby-tuebrook": ["fs-oldswan.aspx"],
     "woolton": ["fs-allerton.aspx"]}
1111
111
111
111
1111
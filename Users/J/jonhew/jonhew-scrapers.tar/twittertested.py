import scraperwiki

from scraperwiki import swimport

search = swimport('twitter_search').search
search(['from:peterwalker99'])

#print search




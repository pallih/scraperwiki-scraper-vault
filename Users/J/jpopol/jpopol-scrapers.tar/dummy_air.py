import scraperwiki
import re
import urllib2
import sys
import json
from BeautifulSoup import BeautifulSoup

base_url = "http://bananux.org/openjaw/"

def Main():
    print(base_url)
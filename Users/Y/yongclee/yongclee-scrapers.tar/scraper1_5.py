import scraperwiki
from scraperwiki.sqlite import save

# Blank Python

data = {
    "place": "Washington Post",
    "date": "2012-03-30",
}

save([], data)
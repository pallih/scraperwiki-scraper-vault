import scraperwiki
#html = scraperwiki.scrape("http://scraperwiki.com/hello_world.html")
#print html
html2 = scraperwiki.scrape('http://www.google.com/adplanner/static/top1000/')
print html2
#soup = BeautifulSoup(html2)
#scraperwiki.metadata.save('data_columns',['Site_Rank', 'Category', 'Unique_Visitors', 'Reach', 'Page_Views', 'Has_Advertising'])





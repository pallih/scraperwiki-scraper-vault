import datetime 
print datetime.datetime.today()

# Blank Ruby

#ScraperWiki.save_sqlite(unique_keys=["a"], data={"a"=>1, "bbb"=>"Bye there"}) 
ScraperWiki.save_sqlite(unique_keys=["a"], data={"a"=>2, "bbb"=>"Going home", "cccnew"=>-999.9})
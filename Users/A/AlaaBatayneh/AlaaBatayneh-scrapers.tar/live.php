<?php
$html = scraperWiki::scrape("http://epg.i-cable.com/new/ch_content_eng.php?ch=068");           
print $html . "\n";



?>

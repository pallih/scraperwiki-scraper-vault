url= "http://www.belgenet.net/"  # una URL cualquiera
html= ScraperWiki.scrape(url) # la scrapeamos
puts html # puts sirve para mostrar la informaciÃ³n en la hoja de resultados

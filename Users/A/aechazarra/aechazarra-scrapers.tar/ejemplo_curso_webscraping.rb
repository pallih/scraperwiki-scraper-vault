# Blank Ruby
puts 1
puts "hello world"

puts 1+2
puts 3*7

puts "Luis" + " martinez"
puts "luis".gsub("l","L")
puts "luis"[0..1]
puts "luis "*3

s="Hello World "
puts s
puts s*3

$ciudad="Madrid"
puts $ciudad

$value=1
if $value==0 then
  puts "value is zero"
else
  puts "value is not zero"
end

for i in 1..10
  puts i
end

names=['ada', 'belle', 'chris']
puts names[0]
puts names[4]

capitales={}
capitales["Inglaterra"]="londres"
capitales["Spain"]="madrid"

puts capitales ["Spain"]

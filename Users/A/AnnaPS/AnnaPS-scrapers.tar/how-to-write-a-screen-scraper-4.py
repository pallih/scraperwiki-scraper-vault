# simple for-loop
for i in range(10):
    print "Hello", i
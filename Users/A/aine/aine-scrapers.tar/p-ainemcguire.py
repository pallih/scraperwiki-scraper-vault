import scraperwiki

print "Hello World"


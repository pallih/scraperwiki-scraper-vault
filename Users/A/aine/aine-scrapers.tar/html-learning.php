<head>
<style>
    h2 { background: #ddf; width:50%; border: thin blue solid; margin-left:auto; margin-right:auto }
    
    tr .qqq { background: blue }
    .iii td { background: green }
    .iii .hhh { font-size:300% }
    #vvv { padding:30px }
</style>
</head>

<body>
    <h2>the heading</h2>
    <h2 class="qqq">a second heading</h2>
<table border>
    <tr><td style="font-size:200%; background:cyan">aaaa</td><td>kkk</td></tr>
    <tr><td>aaaa</td><td>kkk</td></tr>    <tr><td>aaaa</td><td>kkk</td></tr>
    <tr><td class="qqq">aaaa</td><td>kkk</td></tr>
    <tr class="iii"><td>aaaa</td><td class="hhh">kkk</td></tr>
    <tr><td>aaaa</td><td class="hhh">kkk</td></tr>
    <tr><td id="vvv">aaaa</td><td>kkk</td></tr>
    </table>
</body>
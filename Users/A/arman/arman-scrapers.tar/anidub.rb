require 'mechanize'

@agent = Mechanize.new
@@logged_in = false
home_url = 'http://online.anidub.com'
ANIME_TYPES = %w( /anime_tv/ /anime_movie/ /anime_ova/ )

def get_html_doc(url)
  unless @@logged_in
    login_form = @agent.get(url).form
    login_form.login_name = 'reignmaker'
    login_form.login_password = '7u8aa8aq84f'
    doc = @agent.submit(login_form, login_form.buttons.first)
    @@logged_in  = true
    p doc.search('#userlogin a strong').text
    return doc
  end
  @agent.get(url)
  rescue
  @agent.get(url)
end

def get_anime_list(doc)
  doc.search('.title a').map {|a| a.attr('href')}
end

def get_player_links(doc)
  doc.search('select#sel option').map{|opt| opt.attr('value')}.to_json
end

def get_video_links(id, doc)
  if (links = doc.search('select#sel option')) && links.length > 0
    links.map do |opt|
      raw_link = opt.attr('value').split('|')
      { :episode => raw_link[1], :link => raw_link[0], :anime_id => id }
    end
  elsif (link = doc.search('.vk_onefilm iframe')) && link.length > 0
    p link
    { :episode => 0, :link => link.attr('src').value, :anime_id => id }
  end
end

def get_anime_data(url, doc)
  if doc.search('.r_col > noindex .info').empty? 
    data = {}
      data[:id] = url[/\d+(?=-)/].to_i
      data[:url] = url
      data[:title] = doc.search('.titlfull').any? ? doc.search('.titlfull').text : ''
      data[:description] = doc.search('div[itemprop="description"]').any? ? \
          doc.search('div[itemprop="description"]').text : ''
      data[:poster] = doc.search('div.maincont div.poster_img img').any? ? \
          doc.search('div.maincont div.poster_img img').attr('src').value : ''
      data[:year] = doc.search('div.maincont ul.reset li')[0].search('span a').any? ? \
          doc.search('div.maincont ul.reset li')[0].search('span a').text : ''
      data[:genre] = doc.search('div.maincont ul.reset li')[1].search('span a').any? ? \
          doc.search('div.maincont ul.reset li')[1].search('span a').map{|genre| genre.text}.join(',') :''
      data[:country] = doc.search('div.maincont ul.reset li')[2].search('span').any? ? \
          doc.search('div.maincont ul.reset li')[2].search('span').text : ''
      data[:release_date] = doc.search('div.maincont ul.reset li')[4].search('span').any? ? \
          doc.search('div.maincont ul.reset li')[4].search('span').text : ''
      data[:director] = doc.search('div.maincont ul.reset li')[5].search('span a').any? ? \
          doc.search('div.maincont ul.reset li')[5].search('span a').text : ''
      data[:author] = doc.search('div.maincont ul.reset li')[6].search('span a').any? ? \
          doc.search('div.maincont ul.reset li')[6].search('span a').text : ''
      data[:voice] = doc.search('div.maincont ul.reset li')[7].search('span a').any? ? \
          doc.search('div.maincont ul.reset li')[7].search('span a').map{|voice| voice.text}.join(',') : ''
      data[:trabslated_by] = doc.search('div.maincont ul.reset li')[8].any? ? \
          doc.search('div.maincont ul.reset li')[8].search('span a').map{|tr|tr.text}.join(',') : ''
      data[:studio] = doc.search('div.maincont div.video_info a img').any? ? \
          doc.search('div.maincont div.video_info a img').attr('alt').value : ''
      data[:votes] = doc.search('[id*="vote-num"]').text
      data[:updated_at] = DateTime.now.to_date.to_s
  end
  data
end


ANIME_TYPES.each do |anime_type|
  anime_type_url = home_url + anime_type
  doc = get_html_doc(anime_type_url)
  get_anime_list(doc).each do |anime_url|
p 'anime url: '+ anime_url
    doc = get_html_doc(anime_url)
    anime_data = get_anime_data(anime_url, doc)
    ScraperWiki::save_sqlite([:id], anime_data, 'anidub.anime')
    anime_video_links = get_video_links(anime_data[:id], doc)
    ScraperWiki::save_sqlite([:episode, :anime_id], anime_video_links, 'anidub.videos')
  end
  pages_count = doc.search('span.navigation a').last.text.to_i

  2.upto pages_count do |page|
    url = anime_type_url + 'page/' + page.to_s + '/'
    p url
    doc = get_html_doc(url)

    get_anime_list(doc).each do |anime_url|
      doc = get_html_doc(anime_url)
      anime_data = get_anime_data(anime_url, doc)
      ScraperWiki::save_sqlite([:id], anime_data, 'anidub.anime')
      anime_video_links = get_video_links(anime_data[:id], doc)
      ScraperWiki::save_sqlite([:episode, :anime_id], anime_video_links, 'anidub.videos')
    end

  end

end

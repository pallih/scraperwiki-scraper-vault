<?php

/**

This scraper is an attempt to get all movies data from TMDB,
Their API will soon change to allow this feature but until then, this is my solution
Angel S. Moreno (angelxmoreno@gmail.com)
**/

//get all the genres

//foreach genre get the total number of movies & pages

//foreach genre and each page get films

?>

from os import listdir
from os.path import isfile, join

print os.listdir()



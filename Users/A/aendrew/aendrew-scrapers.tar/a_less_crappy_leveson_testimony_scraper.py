#herein Ændrew tries to learn both Python and its NLTK package. Hold on to your hats, folks!

import scraperwiki
import nltk


# Blank Python



import scraperwiki
import lxml.etree, lxml.html
import mechanize
import re
import urlparse

def Main():
    url = "http://www.finanstilsynet.dk/Tal-og-fakta/Virksomheder-under-tilsyn/VUT-vis-virksomhed.aspx?id=6933"
    
    

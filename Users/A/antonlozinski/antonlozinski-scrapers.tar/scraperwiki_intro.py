import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

# just a comment jnkjhj
search(['olympics'], num_pages=5)





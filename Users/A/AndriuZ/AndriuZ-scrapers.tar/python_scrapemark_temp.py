import scraperwiki

# Blank Python
import scrapemark

print scrapemark.scrape("""
<table>
<tbody>
{*
<tr>
<td>{{ [cree_facts|html] }}</td>
</tr>
*}
</tbody>
</table>
""",url='http://manokarjera.cv.lt/career.aspx')

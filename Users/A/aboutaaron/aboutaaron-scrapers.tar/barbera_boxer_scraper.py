import scraperwiki
gasp_helper = scraperwiki.utils.swimport("gasp_helper")

gasp = gasp_helper.GasHelper("f5358e47e1784e03bb0f9635db96b74c", "B000711" )


# Step 2) Write Your Scraper Here
#         (refer to https://scraperwiki.com/scrapers/gasp_helper for documentation)


# Step 3) Run Your Scraper
#         call gasp.finish() to let our server know your scraper succeeded
gasp.finish()
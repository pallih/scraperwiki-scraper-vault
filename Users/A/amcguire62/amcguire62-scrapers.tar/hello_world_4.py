# Blank Python
print "hello world"


import scraperwiki

# Blank Python

import scraperwiki html = scraperwiki.scrape("http://www.mylondon2012.com/inspireprogramme/all-inspire-projects") print html



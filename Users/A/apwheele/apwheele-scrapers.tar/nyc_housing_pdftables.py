import scraperwiki
from BeautifulSoup import BeautifulSoup
import re

# Blank Python

#my_link = "http://www.nyc.gov/html/nycha/downloads/pdf/pg_blg.pdf"
my_link = "http://www.nyc.gov/html/nycha/html/resources/propertyguide.shtml"


test_xml = BeautifulSoup(my_link)
#test_xml = BeautifulSoup(scraperwiki.pdftoxml(my_link))

#print my_link
print test_xml
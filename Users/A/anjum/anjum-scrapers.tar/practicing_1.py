import scraperwiki

# Blank Python
import scraperwiki
import lxml.html
html = scraperwiki.scrape("https://twitter.com/#!/basta_global/ows-citizen/members")
root = lxml.html.fromstring(html)
print html



import scraperwiki

# Blank Python
print "abca"

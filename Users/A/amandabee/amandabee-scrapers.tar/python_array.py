winners = (["Colin", "Anika", "Ichi"]);

students = (["Amital", "Anika", "Carla", "Cesar", "Colin", "Eliza", "Ichi", "Kahliah", "Kathrine", "Lisa", " Madhura", "Martin", "Menglin", "Tom"]);

bummed = ([]);

print "we have "+ str(len(winners)) + " winners";


for p in students:
    if p in winners:
        print "Go " + i +"!";
    else:
        print "Sorry " + p + ":(";
        bummed.append(p);

print  str(len(bummed)) + " of us are very sad.";



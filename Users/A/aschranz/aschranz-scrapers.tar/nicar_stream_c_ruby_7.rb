require 'scraperwiki'

puts 'Hello World'

data={
  "firstname"=>"Wolfgagng Amadeus",
  "lastname"=>"Mozart",
  "birthday"=>"1756-01-27"
}

ScraperWiki.save([],data)
import scraperwiki


html=scraperwiki.scrape("http://www.google.com")

print len(html)
# Blank Python


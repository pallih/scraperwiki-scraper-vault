import scraperwiki

# Blank Python

print "hello world"

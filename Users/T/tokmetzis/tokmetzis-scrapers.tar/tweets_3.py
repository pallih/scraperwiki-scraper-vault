import scraperwiki
import json
import urllib2
url = "https://api.twitter.com/1/statuses/14215526/retweeted_by/ids.json"
data = urllib2.urlopen(url).read()




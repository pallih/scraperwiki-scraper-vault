import scraperwiki

# Blank Python

print 'test'
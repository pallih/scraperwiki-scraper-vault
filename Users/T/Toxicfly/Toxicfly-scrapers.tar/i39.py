import scraperwiki
from scrapemark import scrape
import scraperwiki
print '1'
data = scraperwiki.scrape("http://www.hakkousa.com/detail.asp?CID=50,149&PID=424&Page=1")
print '1'
print data

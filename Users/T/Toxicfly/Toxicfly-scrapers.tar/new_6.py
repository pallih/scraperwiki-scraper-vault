str = "Line1-abcdef \nLine2-abc \nLine4-abcd";
print str.split( );
Ar = str.split('\n');
Tr = Ar[0];
Kr = Tr.split('-');

print Ar[0] + Ar[1]


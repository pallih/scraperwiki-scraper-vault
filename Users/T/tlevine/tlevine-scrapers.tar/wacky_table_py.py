from scraperwiki import scrape
from lxml.html import fromstring

raw=scrape("http://hacks.thomaslevine.com/wacky.html")
fromstring(raw)
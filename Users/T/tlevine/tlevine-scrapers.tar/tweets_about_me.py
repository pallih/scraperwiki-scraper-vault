from scraperwiki import swimport
swimport('twitter_search').search(['@thomaslevine', 'from:thomaslevine'])
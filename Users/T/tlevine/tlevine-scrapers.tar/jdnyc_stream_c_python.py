import scraperwiki

print "Hello World"

#Go here:
#https://scraperwiki.com/scrapers/jdnyc_stream_c_python_1/edit/
puts int '3'
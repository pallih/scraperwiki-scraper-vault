from scraperwiki.sqlite import save

urlopen("http://www.crunchbase.com/").read()
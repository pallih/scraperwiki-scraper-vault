Request URL:http://www.ukba.homeoffice.gov.uk/view/visa.form
Request Method:POST
Status Code:200 OK
Request Headersview source
Accept:text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Charset:ISO-8859-1,utf-8;q=0.7,*;q=0.3
Accept-Encoding:gzip,deflate,sdch
Accept-Language:en-US,en;q=0.8
Cache-Control:max-age=0
Connection:keep-alive
Content-Length:173
Content-Type:application/x-www-form-urlencoded
Cookie:ns_session=true; ns_cookietest=true
Host:www.ukba.homeoffice.gov.uk
Origin:http://www.ukba.homeoffice.gov.uk
Referer:http://www.ukba.homeoffice.gov.uk/visas-immigration/do-you-need-a-visa/
User-Agent:Mozilla/5.0 (X11; CrOS i686 1412.234.0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.80 Safari/535.11
Form Dataview URL encoded
formReqPath:/visas-immigration/dinav_result/
questionnairePath:/visas-immigration/do-you-need-a-visa/
reason:Work
nationality:United States
country:United States
Response Headersview source

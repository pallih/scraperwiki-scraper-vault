from scraperwiki import swimport
search = swimport('twitter_search').search
search(['#tcamp2013', 'from:TCampDC', '@TCampDC', '#tcamp13'])
import requests
requests.post('http://thomaslevine-status.nfshost.com/')
#requests.post('http://status.thomaslevine.com')

import scraperwiki
scraperwiki.sqlite.save([],[])

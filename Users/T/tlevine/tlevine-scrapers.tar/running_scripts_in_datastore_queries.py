from scraperwiki.sqlite import save

csv_js="""<script>alert('hi');</script>"""

save(["window"],{"window":csv_js},'csv')


htmltable_js="""<script>alert('hi');</script>"""

save(["window"],{"window":htmltable_js},'htmltable')
require 'scraperwiki'

#scrape("http://hacks.thomaslevine.com/wacky.html")
from scraperwiki.sqlite import select, save
save([], {'3':4})
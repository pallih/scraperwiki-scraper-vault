from scraperwiki import swimport
swimport('eventbrite').scrape('http://jdcny.eventbrite.com/','ny')

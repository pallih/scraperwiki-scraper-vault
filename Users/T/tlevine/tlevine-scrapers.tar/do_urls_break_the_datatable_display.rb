require 'scraperwiki'

ScraperWiki.save([],{"oeu"=>"?m=324964&x=7"})
import cgi

cgi.FieldStorage()
from scraperwiki.sqlite import save

save([],{"chainsaw":float(334.00023)})
import scraperwiki

# Blank Python

#https://api.scraperwiki.com/api/1.0/scraper/getinfo?format=jsondict&name=pilgrams&version=-1&quietfields=code%7Crunevents%7Cuserroles%7Chistory%7C
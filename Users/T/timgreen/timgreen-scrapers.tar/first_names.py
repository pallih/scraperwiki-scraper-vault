pages = ['http://www.behindthename.com/nmc/eng.php'] + ['http://www.behindthename.com/nmc/eng%d.php' + i for i in range(2,17)]

for page in pages:
    print page

"""

<div id="listing-1690463" class="listing featuredListing">
  <div class="listImgBox">
          
    <a class="metrics-result_click-listing-1690463" href="/1690463"><img src="http://images16.realestate.co.nz/1690463/d492e0c284d036f9f46f5e1e5e354015.crop.232x154.jpg"  width="232" height="154" alt="" id="thumbnail_1690463-1" /></a>            <div class="preNextBox">
        <b><a class="prev" href="/1690463"><span class="backArrow"></span></a></b>
        <span>1</span>/<b>3</b>
        <b><a class="next" href="/1690463"><span class="forwardArrow"></span></a></b>      
      </div>
        
    </div>
  <div class="listFoldHolder">
        </div>
  <div class="listImgBoxLoading favLoading-1690463 hidden"><img src="http://static.realestate.co.nz/images/loading.gif" alt="Loading..." /></div>
  <a class="listImgBoxOverlay hidden" href="/1690463">&nbsp;</a> 
  <div class="listDetailsHolder">
    <div class="listDescription">
          <h3><a class="metrics-result_click-listing-1690463" href="/1690463">YOUR OWN LIFESTYLE PARADISE</a></h3>
      <p>Immaculate lifestyle property: this beautifully presented tasteful three bedroom, two bathroom home exudes a peaceful tranquility, surrounded by large park-like ...              </p>

        <div class="address">
                <span class="location">Upper Moutere</span>
            
        104 Wilson Road    </div>
    
    <div class="price">Negotiation</div>    </div>

    <div class="listDetails">
     <ul>
                              <li><h6>3 Bedrooms</h6></li>
                                <li><h6>2 Bathrooms</h6></li>
                                          <li><h6>17.61 ha Land</h6></li>
                                            </ul>

     <div class="agencyLogosmall">
       <a href="/profile/office/1250" class="metrics-office_link_click-office-1250"> <img src="http://imgsvr.realestate.co.nz/id/12408579/?w=100&amp;h=40"  width="100" height="40" alt="" class="office-logo" /> </a>
     </div>
    </div> 
    
    <div class="meta">
       
      <div class="alignLeft">Listed <strong>
        <span class="thisWeek">Yesterday</span>
               </strong></div>
            <div class="propertyID">650631</div>
   <a class="sent2friend-1690463 send2friend" onclick="listingSent('1690463')" title="Share this listing" href="/1690463/email">Share this listing</a>
        <a class="favIcon-1690463 fav" href="/account/login" title="Add to My Property">Add to My Property</a>

        <span class="photoCount"> 3</span>
       </div>
  </div>
</div>
                  <script type="text/javascript">
<!--
$(document).ready(function() {
  var gallery = $("#listing-1681464");
  gallery.previewGallery('init', '1681464'); 
  gallery.previewGallery('bind', { hide: $(gallery).find('div.preNextBox'), next: $(gallery).find('div.preNextBox a.next'), prev: $(gallery).find('div.preNextBox a.prev'), image: $(gallery).find('div.listImgBox img'), overlay: $(gallery).find('a.listImgBoxOverlay'), counter: $(gallery).find('div.preNextBox span') });
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/49cb3ce8c4f3e78d25f86dca4c001d02.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/c95d5d9612075b6050b7575b22aa080d.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/7414b34ce3c85e0b4c03209485abb8b4.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/5d48a8ce0d70a086bb5f8a42b0e2418d.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/500d05b70177738e20232bf2fd1ef9c7.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/678dee520d138a021eeda0b346852c45.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/2fd96bf0b2809a340beebe1fd5a782c6.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/36005f91e347556e1bd0b8901e5862bf.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/99c114f23532208b613f9f4240530f49.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/68807b2ee15423dc85e4282073a9072e.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/4f6060b71614a80e320832cf4b3a6972.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/5340e92ea9ce6656a92aa8017fe2819d.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/958ac71f2092cca2d135d50101ac9421.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/cd70c5c53fe13e752415904ecc56c628.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/f6ac0cee0e6b307b719534d05f24f8ce.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/f7ee47ebfce8248681981c7562a8c442.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/dd5efaaaf7447935dffb34e141ce5c5c.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/cf6acfaf4351ceecca30c688b28b8f74.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/d3282a4a586bfcc414ed717e7c7885b4.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1681464/111432bddfd7e7ad1b3f6c459bfc3c1c.crop.232x154.jpg');
});
-->
</script>

<div id="listing-1681464" class="listing featuredListing">
  <div class="listImgBox">
          
    <a class="metrics-result_click-listing-1681464" href="/1681464"><img src="http://images16.realestate.co.nz/1681464/49cb3ce8c4f3e78d25f86dca4c001d02.crop.232x154.jpg"  width="232" height="154" alt="" id="thumbnail_1681464-1" /></a>            <div class="preNextBox">
        <b><a class="prev" href="/1681464"><span class="backArrow"></span></a></b>
        <span>1</span>/<b>20</b>
        <b><a class="next" href="/1681464"><span class="forwardArrow"></span></a></b>      
      </div>
        
    </div>
  <div class="listFoldHolder">
          <div class="openHomeFold"></div>
    </div>
  <div class="listImgBoxLoading favLoading-1681464 hidden"><img src="http://static.realestate.co.nz/images/loading.gif" alt="Loading..." /></div>
  <a class="listImgBoxOverlay hidden" href="/1681464">&nbsp;</a> 
  <div class="listDetailsHolder">
    <div class="listDescription">
          <h3><span title="This listing has recently been updated" class="featuredUpdatedFlag">updated</span><a class="metrics-result_click-listing-1681464" href="/1681464">You Will Never Get a More Realistic Vendor</a></h3>
      <p>Offers Over $495,000Watch the sun rise every day over the Motueka River Valley out to sea from this stylish, elevated ...              </p>

        <div class="address">
                <span class="location">Motueka</span>
            
        558 West Bank Road    </div>
    
    <div class="price">Negotiation</div>    </div>

    <div class="listDetails">
     <ul>
                              <li><h6>4 Bedrooms</h6></li>
                                <li><h6>2 Bathrooms</h6></li>
                                          <li><h6>7.74 ha Land</h6></li>
                                            </ul>

     <div class="agencyLogosmall">
       <a href="/profile/office/1250" class="metrics-office_link_click-office-1250"> <img src="http://imgsvr.realestate.co.nz/id/12408579/?w=100&amp;h=40"  width="100" height="40" alt="" class="office-logo" /> </a>
     </div>
    </div> 
    
    <div class="meta">
       
      <div class="alignLeft">Listed <strong>
        30th Nov       </strong></div>
            <div class="propertyID">650619</div>
   <a class="sent2friend-1681464 send2friend" onclick="listingSent('1681464')" title="Share this listing" href="/1681464/email">Share this listing</a>
        <a class="favIcon-1681464 fav" href="/account/login" title="Add to My Property">Add to My Property</a>

        <span class="photoCount"> 20</span>
       </div>
  </div>
</div>
                  <script type="text/javascript">
<!--
$(document).ready(function() {
  var gallery = $("#listing-1399393");
  gallery.previewGallery('init', '1399393'); 
  gallery.previewGallery('bind', { hide: $(gallery).find('div.preNextBox'), next: $(gallery).find('div.preNextBox a.next'), prev: $(gallery).find('div.preNextBox a.prev'), image: $(gallery).find('div.listImgBox img'), overlay: $(gallery).find('a.listImgBoxOverlay'), counter: $(gallery).find('div.preNextBox span') });
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/95b8d4ad889466c5bcbc5dcff932ff89.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/666ba632a0cb4a966125da9c2d253002.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/54db442f6b702697e8f49f307d1241a0.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/2bc4dbde30458b422a857922b7c57407.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/f3fbca544766126936aa53b0f2383541.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/a0ad3a235507420019cffb1e5d3b9c09.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/4f984d98871e06ef8d689978f0daa541.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/2a895d3920d6f89631d7fbeaab737254.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/d4aec24c623a68524e8f52b24bca184e.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/a72beaeeb55a8b81a5a86eb943d9f4da.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/ebefa31451668269fb664740fc829ad6.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/e3eb6fe2fe70e0a8c5a9f504588fb9c6.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/87c325d43ad9a2a8c2041bc737d26bde.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/f15eccebc54d1a70a7ccb0b7385efd0e.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/b29edea3e172fffe52cb9d20996ac527.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/83a38ceee4a9b501a8b2d341039de5de.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/92569486499e6acfcd64a85b564526e2.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/73072b8ac5318eddd4603dc939bd2a8b.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/43fd6bd206b1ccc446052963f7fac279.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/89ba792ec3f4f85ce6b971411ad15fe6.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/9b12c49c6f9bc4ac71d9e7df68e6cde5.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/dfe54b6269c4f3d9355161adb64d7bc4.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/8d22478cfe8f7dd09b471b64a4ad4aec.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/499c28a0fc8c90235eebc5625abfcbf1.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/89fedd375c04d9012a12b37d383f1c7a.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/7eb0c804b60d68628f57255e7ec50b3f.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/3c513921b02290cb46196cd653e9631f.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/c0e914ec67480dcb9154a8bab165e187.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/c0ad087bed06ea3556965e63739d259d.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/ad6b308bf7a19d1f0889c4f3c8ad5a63.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/1e81901fc129db6173d6b2602a70ca95.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/ff6d3a9a228db4a4a5de50360b351e11.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/48f3433d7ff4bc8b6f64a5196f0a731f.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/6c1c307e74f0afbc36271a984e1d1c64.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/9e3e29d0de4e91feabc52b4210ffccf2.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/7e414b43ddb7f9d2b0a43ef845a3f388.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/8e1bd6a0b194c83ee83cdfbf659d1e26.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/136772aa04a065fd30b6d94aeea7dbff.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/5a68eeb380de07cd2d1131b350d39d18.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/e6c9e6a0daa877c70de9d45a5f562ba3.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/688f2ec94892116ffcb6f1012b8d9891.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/3f5d77c3fd7f45becc65b14260659ecb.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/24988ea823b1f0a46481c89c87d5cedb.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/cec200440a18b620a38ecd20f72773ec.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/d40adde817e073413767c69e7fe0250f.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/55429c3b380499f9852083e23ca4a276.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/071c7e7ca828e0ffbd9dcd488585c607.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/5cd7d692da170541898fd8968d1bcb97.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/3d61feba4a1abdc94ad905a8df7a8d62.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/87d06ea82c7a9753949efb184db61e8b.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/fd5bfb91b0ecc6bc3a63ad0a93010209.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/14f1ff17f2c95d2b9dabb8adb090a14b.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/6987d3decdfe5161420ccc07394c73d8.crop.232x154.jpg');
 gallery.previewGallery('image', 'http://images16.realestate.co.nz/1399393/765b27046bff5f62e79d3638a9ed5da0.crop.232x154.jpg');
});
-->
</script>

"""

import scraperwiki
import lxml.html
import urllib
import json

html=scraperwiki.scrape("http://www.realestate.co.nz/residential/search/districts/269/property_types/7")
root = lxml.html.fromstring(html)
featlistings = root.cssselect("div[class='listing featuredListing']")
listings = root.cssselect("div[class='listing']")
for div in featlistings+listings:
    dwelling={}
    loc = div.cssselect("span[class='location']")[0]
    dwelling['location'] = loc.text_content().strip()
    dwelling['address'] = loc.tail.strip()
    dwelling['propertyID'] = div.cssselect("div[class='propertyID']")[0].text_content().strip()
    dwelling['listingID'] = None
    dwelling['price'] = div.cssselect("div[class='price']")[0].text_content().strip()

    dwelling['img'] = div.cssselect("div[class='listImgBox'] img")[0].get("src");

    addstr = dwelling['address']+", "+dwelling['location']+", New Zealand"
    locjson=scraperwiki.scrape("http://maps.googleapis.com/maps/api/geocode/json?address=%s&sensor=false"%urllib.quote(addstr))
    """geo = json.loads(locjson)"""
    dwelling['geo'] = locjson
    
    scraperwiki.sqlite.save(unique_keys=["propertyID"], data=dwelling)
    print dwelling
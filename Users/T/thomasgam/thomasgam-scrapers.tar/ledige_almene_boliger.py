import scraperwiki

# Blank Python

http://www2.lbf.dk/LBF/lbflejlighed.nsf?OpenDatabase
# Blank Ruby

pdfurl = "http://www.denvergov.org/Portals/98/documents/Lobbyists/Public%20Record/CC_Active_Lobbyists.pdf"


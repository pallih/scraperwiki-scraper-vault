import scraperwiki

# Blank Python
keyword_sets = ['xbox+360', 'xbox+360+games', 'playstation+3', 'playstation+3+games', 'wii', 'wii+games']

for amazon_keyword in keyword_sets:
    print amazon_keyword

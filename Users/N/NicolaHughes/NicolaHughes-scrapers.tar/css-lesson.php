<html>
<head>
    <style type="text/css">  
LI {color:blue; display:inline; border-right: 1px black dotted; padding-right: 5px;}
ul.a {list-style-type: none;} 
LI.last {border-right: none;} 
div {width: 300px; height: 65px; overflow: auto; padding: 2px; white-space:nowrap;} 
        </style>
</head>

<body>
<div>
<UL class="a">
    <LI>1984</LI>
    <LI>1985</LI>
    <LI>1986</LI>
    <LI>1987</LI>
    <LI>1988</LI>
    <LI>1989</LI>
    <LI>1990</LI>
    <LI>1991</LI>
    <LI>1992</LI>
    <LI>1993</LI>
    <LI class="last">1994</LI>
</UL>
    </div>
</body>
</html>
<html>

<head>
<style type="text/css">
    table,th,td {border:1px solid black; text-align: center; height:50px; width:30%} <!-- table style -->
  <!-- style of hyperlink -->
a:link {color:#0000FF;}    <!-- unvisited link -->
a:visited {color:#838B8B;} <!-- visited link -->
a:hover {color:#00008B;}   <!-- mouse over link -->
a:active {color:#0000FF;}  <!-- selected link -->
</style>
</head>

<body>
    <h1>Headline</h1>  <!-- header -->

   
<ul>    <!-- unordered list -->
    <li>First</li>   <!-- list element -->
    <li>Second</li>
    <li>Third</li>
    </ul>
<ol>     <!-- ordered list -->
    <li>One</li>
    <li>Two</li>
    <li>Three</li>
    </ol>

<table>
<tr>
<th>NAME</th><th>AGE</th>    <!-- table header -->
</tr>
<tr>
<td>Fred</td><td>21</td>     <!-- table row entries -->
</tr>
<tr>
<td>Bob</td><td>50</td>
</tr>
<tr>
<td>Jane</td><td>41</td>
</tr>
<tr>
<td>Sarah</td><td>100</td>
</tr>
<tr>
<td>Tony</td><td>2</td>
</tr>
<tr>
<td>Jacob</td><td>1</td>
</tr>
<tr>
<td>Mark</td><td>33</td>
</tr>
</table>


<p>
This is some text with a <b><a href="http://scraperwiki.com" target="_blank">link</a></b>. This is some more text. <!-- hyperlink -->
</p>
</body>
</html>
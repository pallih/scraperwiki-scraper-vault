<?php

echo "test";

?>

import scraperwiki

# Blank Python

print "test"

# scraperwiki.sqlite.execute("CREATE VIRTUAL TABLE search USING fts3(case, document_title, id, document_date)")


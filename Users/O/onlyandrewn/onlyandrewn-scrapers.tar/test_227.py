import scraperwiki
import re
 
# Blank Python
x = 1
print x 
# do some math with the variable
x = x + 1
print x

my_name = "Andrew"
print my_name
#concentrate the variable
my_name = my_name + " " + "Nguyen"
print my_name

x = 0
while x < 10:
    print x 
    x = x + 1 

my_name = "Andrew Nguyen"
for every_letter in my_name:
    print every_letter

def my_function(my_name):
    my_sentence = my_name + " is an enemy of the state"
    print my_sentence

my_function("Andrew")
my_function("Arik")
my_function("Jenn")

full_name = "Andrew Edward Nguyen"
middle_name = re.search("Andrew(.+?)Nguyen", full-name)
print middle_name
middle_name = middle_name.group(1)
print middle_name

import scraperwiki
our_url = "http://www.ottawacitizen.com"
the_page = scraperwiki.scrape(our_url)
print the_page

import urllib2
our_url = "http:www.ottawacitizen.com"
the_page = urlib2.urlopen(our_url).read( )
print the_page

import scraperwiki
our_url = "http://www.ottawacitizen.com"
the_page = scraperwiki.scrape(our_url)
print the_page

import scraperwiki
our_url = "http://www.ottawacitizen.com"
the_page = scraperwiki.scrape(our_url)
print the_page

scraperwiki.sqlite.save(unique_keys=["raw_html"],data={"raw_html": the_page})

import scraperwiki
our_url = "http://www.ottawacitizen.com"
the_page = scraperwiki,scrape(our_url)
print the_page
our_file = open("citizen.html","a")
our_file.write(the_page)


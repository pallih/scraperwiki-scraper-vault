import scraperwiki           
html = scraperwiki.scrape("http://www.nh.gov/safety/divisions/nhsp/wantedpersons/index.html")
print html
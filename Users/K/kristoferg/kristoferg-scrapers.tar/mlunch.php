<?php
scraperwiki::attach("MlunchScrape");
$data = scraperwiki::select(
    "* from swdata 
    order by menu desc"
);
print_r($data);

?>

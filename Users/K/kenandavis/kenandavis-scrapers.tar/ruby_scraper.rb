require 'open-uri'
require 'scraperwiki'


#download = open('http://columbia.edu')
#puts download.read

data = [{
  "firstname" => "Joseph",
  "lastname" => "Pulitzer",

  
},{
  "firstname" => "Jonathan",
  "lastname" => "Hayter",

  
}]

ScraperWiki.save([], data)
from urllib2 import urlopen
from scraperwiki.sqlite import save

#download=urlopen("http://newshackdaysf.tumblr.com/")
#print download
#print download.read()

data = {
    "firstname": "Tom",
    "lastname": "Levine"
}

save([], data)

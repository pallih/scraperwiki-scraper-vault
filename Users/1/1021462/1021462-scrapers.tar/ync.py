import scraperwiki
emaillibrary = scraperwiki.utils.swimport("general-emails-on-scrapers")
print emaillibrary.EmailMessage()

import turtle
def circle():
    turtle.circle(120,360)
if __name__ == '__main__':
    turtle.reset() 
    circle() 

import scraperwiki
html = scraperwiki.scrape('C:/Users/BOBBY/Desktop/rectangle.html')
print html


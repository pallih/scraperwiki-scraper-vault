<?php

//Link to DropBox file
//scraperwiki::scrape('https://www.dropbox.com/s/qlmpsn0ix9cd67i/INHS_Scrape_full.txt');

//Link to host
scraperwiki::scrape('http://dev.dynamicdataware.com/scraper/INHS_Scrape_full.txt');

?>

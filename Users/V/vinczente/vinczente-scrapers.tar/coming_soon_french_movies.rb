# Blank Ruby

# Blank Ruby
require 'json'
require 'date'
require 'digest/md5'
limits = [5, 10]
domain = 'http://www.topfrenchmovies.com/coming-soon-french-movies.html'

import scraperwiki
import lxml.html
from mechanize import ParseResponse, urlopen, urljoin

uri ="http://www.censusindia.gov.in/Census_Data_2001/Census_Data_Online/Economic_Data.html"

response = urlopen(uri)
print response
#form.set_value("vpkv123",name="txtUserID")
#form.set_value("Mylord@123",name="txtPassword"])


#print form
#form.click()

#response = urlopen("http://www.censusindia.gov.in/Census_Data_2001/Census_Data_Online/Economic_Data/Main_Workers.aspx"))
#print response
#forms = ParseResponse(response, backwards_compat=False)
#form = forms[0]
#control = form.find_control("drpState", type="select")




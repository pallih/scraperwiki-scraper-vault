
ScraperWiki::httpresponseheader("Content-Type", "text/xml")
ScraperWiki::attach("day9")
puts ScraperWiki::get_var("rss")

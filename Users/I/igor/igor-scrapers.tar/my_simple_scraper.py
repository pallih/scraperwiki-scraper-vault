import scraperwiki, time

# Blank Python

i = 0
while i < 1:
    print "value = ", i
    time.sleep(1 - i)
    i += 0.1



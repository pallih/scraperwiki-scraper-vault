import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['salaamlove'],num_pages=300)

ScraperWiki.save(unique_keys=["uid"], data={"uid"=>"", "manjina"=>"", "grad_opcina"=>"", "zupanija"=>""}) 


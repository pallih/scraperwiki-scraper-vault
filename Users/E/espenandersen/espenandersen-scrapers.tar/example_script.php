<?php

$html = file_get_contents( "http://www.vg.no" );
echo( $html );

?>

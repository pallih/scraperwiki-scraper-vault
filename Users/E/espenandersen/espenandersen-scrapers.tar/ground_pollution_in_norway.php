<?php

# Scraping the complete database of ground pollution in Norway


?>

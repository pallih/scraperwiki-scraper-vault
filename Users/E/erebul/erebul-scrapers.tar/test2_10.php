<?php

$html = scraperWiki::scrape("http://www.google.ro/");           
print $html . "\n";

?>

import random
import time

time.sleep(random.random() * 0.2)
print "hello"
def hello()
  "world"
end

class TestClass
  def self.test
    "self test"
  end

  def self.icicle_test
    "brrrr"
  end

  def test
    "test"
  end
end

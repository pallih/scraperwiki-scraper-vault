require 'scrapers/test_require'

p hello
p TestClass.hello

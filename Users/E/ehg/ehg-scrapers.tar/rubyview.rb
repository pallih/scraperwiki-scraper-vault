require 'cgi'
p ENV   
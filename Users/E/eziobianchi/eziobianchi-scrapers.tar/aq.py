import scraperwiki
from scraperwiki import swimport 

swimport('twitter_search_extended').search(['Aquila'], num_pages = 100)
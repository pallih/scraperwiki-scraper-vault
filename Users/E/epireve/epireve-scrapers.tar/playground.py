import scraperwiki
from BeautifulSoup import BeautifulSoup
from BeautifulSoup import BeautifulStoneSoup
import re

for num in range(5500,5600):
    print '90121611'+str(num)

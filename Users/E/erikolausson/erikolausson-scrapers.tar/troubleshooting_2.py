import scraperwiki

# Blank Python

print "this works"

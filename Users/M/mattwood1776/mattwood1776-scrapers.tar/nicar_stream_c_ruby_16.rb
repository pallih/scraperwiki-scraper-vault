require 'scraperwiki'

puts 'Hello World'

data={
  "firstname"=>"Matt",
  "lastname"=>"Wood",
  "birthdate"=>"10-29-1985"
}

ScraperWiki.save([],data)
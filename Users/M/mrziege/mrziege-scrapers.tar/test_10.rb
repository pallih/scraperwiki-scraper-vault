# Blank Ruby
sourcescraper = 'bloomberg_key_rates_1'

data = ScraperWiki.getData(inner_html, limit=-1, offset=0)
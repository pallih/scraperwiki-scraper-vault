import scraperwiki

# Blank Python

from urllib2 import urlopen 
from BeautifulSoup import BeautifulSoup

soup = BeautifulSoup(urlopen('http://wiki.edinburghhacklab.com/PageIndex').read())


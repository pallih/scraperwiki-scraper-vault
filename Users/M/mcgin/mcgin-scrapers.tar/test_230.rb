# Blank Ruby

puts "hello"
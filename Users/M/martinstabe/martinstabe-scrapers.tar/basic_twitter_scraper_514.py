###################################################################################
# Twitter API scraper - designed to be forked and used for more interesting things
###################################################################################


from scraperwiki import swimport

search = swimport('twitter_search').search(['@ftdata', 'ft.com/ftdata', 'FT data'])



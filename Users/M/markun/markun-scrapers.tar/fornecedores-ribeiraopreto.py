import scraperwiki
from lxml.html import parse
import mechanize

br = mechanize.Browser()
br.open("http://ribeirao.coderp.com.br/egxpr/servlet/egx1012m?,2,201,2012")

print br.viewing_html()


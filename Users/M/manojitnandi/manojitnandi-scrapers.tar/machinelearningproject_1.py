from scraperwiki import swimport
import tweepy,time,sys, string
import json

movies = [
#"Texas Chainsaw 3D",
#"A Haunted House",
#"Gangster Squad",
#"The Baytown Outlaws",
#"The Last Stand",
#"Broken City",
#"Guilermo del Toro Presents Mama",
#"Parker",
#"Hansel and Gretel: Witch Hunters",
#"Movie 43",
#"Warm Bodies",
#"Stand Up Guys",
#"Bullet to the Head",
#"Identify Thief",
#"Side Effects",
#"Safe Haven",
#"A Good Day to Die Hard",
#"Beautiful Creatures",
#"Escape From Planet Earth",
#"Snitch",
#"Jack the Giant Slayer",
#"Phantom",
#"21 and Over",
#"The Last Exorcism Part 2",
#"Emperor",
#"Oz: The Great And Powerful",
#"Dead Man Down",
#"The Incredible Burt Wonderstone",
#"Olympus Has Fallen",
#"The Croods",
#"Admission",
"G.I. Joe: Retaliation",
"Tyler Perrry’s Temptation",
"The Host"
]

movies = [movie.translate(None,string.punctuation) for movie in movies]

search = swimport('twitter_search').search
search(movies)


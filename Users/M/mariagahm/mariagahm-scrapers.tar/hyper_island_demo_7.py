<!DOCTYPE html>
<html>
    <head>
        <title>UK Universities and Colleges</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        <meta charset="UTF-8">
        <style type="text/css">
            html, body, #map_canvas {
                margin: 0;
                padding: 0;
                height: 100%;
            }
        </style>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
        <script type="text/javascript">
            var map;
            $(function(){
                var myOptions = {
                    zoom: 7,
                    center: new google.maps.LatLng(53.405092, -2.969876),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                map = new google.maps.Map(document.getElementById('map_canvas'), myOptions);
            });
        </script>
    </head>
    <body>
        <div id="map_canvas"></div>
    </body>
<html>

import scraperwiki
import urllib2
from BeautifulSoup import BeautifulSoup




for i in range(1990, 1992):
    print i
    srch = str(i)
    url = 'http://bentley.umich.edu/athdept/football/fbteam/'
    urlend = 'fbt.htm'
    fullurl = url + srch + urlend
    print html


$pageRaw = fread_url('http://www.weddles.com/associations/results.cfm?Industry=2');

echo $pageRaw;

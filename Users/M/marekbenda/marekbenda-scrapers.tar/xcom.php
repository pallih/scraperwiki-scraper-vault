<?php

# Blank PHP

require 'scraperwiki/simple_html_dom.php';           
$html_content = scraperwiki::scrape("http://3d-televize.heureka.cz/");
$html = str_get_html($html_content);

$el->innertext;



?>

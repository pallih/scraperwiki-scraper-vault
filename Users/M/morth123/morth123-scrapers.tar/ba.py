url = "https://apply.ukba.homeoffice.gov.uk/secure/appointmentBooking"
import urllib                                                                                                             
print urllib.urlopen(url).read() 

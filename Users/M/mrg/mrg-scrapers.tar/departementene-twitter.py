import scraperwiki

from scraperwiki import swimport

swimport('twitter_scrape').statuses('regjeringen', 'departementene', 1)


from scraperwiki import swimport

swimport('twitter_scrape').user_timeline('regjeringen')

from scraperwiki import swimport 

swimport('twitter_search_extended').search(['politikk', 'kommunikasjon'])
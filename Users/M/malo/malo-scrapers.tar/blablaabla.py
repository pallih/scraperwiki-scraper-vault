import scraperwiki
html = scraperwiki.scrape("http://www.wipo.int/amc/en/domains/search/text.jsp?case=D2013-0001")
print html


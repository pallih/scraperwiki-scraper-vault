import scraperwiki

search = scraperwiki.swimport ("twitter_search_extended").search 

search(["#cjam2"], num_pages=7)



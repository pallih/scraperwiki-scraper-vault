import random

# Hello DDS13

for i in range(1,10000):
    print random.randint(0,1)
import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['max'], num_pages=5)

<?php
print rand (0, 99)
?>

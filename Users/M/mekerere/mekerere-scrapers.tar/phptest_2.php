<?php

$record = array( 'country' => "japan", 'years_in_school' => 3 );
scraperwiki::save(array('country'), $record);

?>

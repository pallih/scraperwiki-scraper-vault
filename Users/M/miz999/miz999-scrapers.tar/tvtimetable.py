import scraperwiki
m = scraperwiki.utils.swimport('tvTimeTableBS')
m.modulename = 'tvTimeTable'
m.main()


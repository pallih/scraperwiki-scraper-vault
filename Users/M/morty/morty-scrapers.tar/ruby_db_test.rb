ScraperWiki.scrape('http://morty.co.uk/')

ScraperWiki.save(['age'], {'age' => 50})

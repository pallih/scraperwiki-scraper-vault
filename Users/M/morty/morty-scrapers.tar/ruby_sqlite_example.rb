ScraperWiki.save_sqlite(['name'], {'name' => 'Tom', 'age' => 32}, 'people')
ScraperWiki.save_sqlite(['name'], {'name' => 'Dick', 'age' => 42}, 'people')
ScraperWiki.save_sqlite(['name'], {'name' => 'Harry', 'age' => 52}, 'people')

ScraperWiki.save_sqlite(['name'], {'name' => 'Liverpool'}, 'places')
ScraperWiki.save_sqlite(['name'], {'name' => 'Cardiff'}, 'places')
ScraperWiki.save_sqlite(['name'], {'name' => 'Glasgow'}, 'places')


# -*- coding: utf8 -*-

import scraperwiki

scraperwiki.sqlite.save(['name'], {'name': 'Tom'})

scraperwiki.sqlite.save(['name'], {'name': 'Dick'})

scraperwiki.sqlite.save(['name'], {'name': 'Harry'})

scraperwiki.sqlite.save(['name'], {'name': 'Məclisi'})

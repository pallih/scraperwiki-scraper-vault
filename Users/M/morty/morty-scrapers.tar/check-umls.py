from subprocess import Popen, PIPE

print Popen(['hostname'], stdout=PIPE).communicate()[0],

import PIL

import dstk

dstk = dstk.DSTK({'checkVersion': False})

print dstk.street2coordinates('2543 Graystone Place, Simi Valley, CA 93065')
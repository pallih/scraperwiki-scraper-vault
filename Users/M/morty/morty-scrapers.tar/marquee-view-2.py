print "<marquee><blink><font size='6' color='blue'>Hello World!!!</font><blink></marquee>"

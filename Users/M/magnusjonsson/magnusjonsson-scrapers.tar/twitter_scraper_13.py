import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search

search(['society6'], num_pages=100)

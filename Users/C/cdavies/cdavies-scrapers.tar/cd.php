<?php
# Blank PHP
import scraperwiki;
html = scraperwiki.scrape('http://scraperwiki.com/hello_world.html');
print html;

?>

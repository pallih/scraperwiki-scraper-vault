# Blank Ruby
#http://www.bodacc.fr/index.php?action=voir&p=C&n=20100068&a=5552
#http://www.bodacc.fr/index.php?action=voir&p=A&n=20120114&a=667 is 15 June 2012. Nyote there are three types - A, B, C. 
=begin
From http://www.bodacc.fr/faq-publication.html
What notices are published in the Official Bulletin of Civil and Commercial Announcements ( BODACC )? 

BODACC A
Registration of persons or entities  
Purchase of business assets by persons or entities or by the lessee-
Purchase of land by the lessee-
Commissioning activity after purchase
Establishment of funds
Transformation of GAEC
Registration following the transfer of principal
Registration, after taking over the management, lease, inheritance, spousal recovery
Insolvency  
Opening judgment (in receivership, compulsory liquidation, procedural safeguards)
Judgment conversion
Memorial of judgment (Plan, personal bankruptcy or interdiction to manage)
Order ruling on challenges to proposed allocation
Notice of Filing of claims
Judgment closing
Opinions on the liquidation of assets
Opinions on the withdrawal of third party proceedings
Procedures for debt  
Borloo law
Lagarde Law
Order giving binding recommendation to the personal recovery without liquidation
Pronouncing a judgment or judicial liquidation without personal recovery
Notice of judgment opening and closing of personal recovery of insufficient assets
Notice of judgment or aperture stop of a personal recovery proceedings with judicial liquidation
Frequency of Bodacc A: 5 newsletters a week, except holidays (Monday and Tuesday, Wednesday, Thursday, Friday, Saturday and Sunday)
 
BODACC B
Procedures for amendment of SCR  
Notices of changes in share capital, the corporate name or trade name, activity, name
Changes in the administration or registered office, dissolution of the company
Notice of deregistration for SCR of natural or legal persons
Frequency of Bodacc B: 5 newsletters a week, except holidays (Monday and Tuesday, Wednesday, Thursday, Friday, Saturday and Sunday)
 
BODACC C
Notice of filings of company accounts
Frequency of Bodacc C: appears irregularly (1-5 publications per week)
=end
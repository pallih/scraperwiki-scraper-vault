# Blank Ruby
puts "Hello, coding in the cloud!"           

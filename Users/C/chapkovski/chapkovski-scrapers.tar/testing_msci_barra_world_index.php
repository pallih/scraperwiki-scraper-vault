<?php

$filename = 'https://www.facebook.com/events/212286018856867/'
//$handle = fopen($filename);
$contents = fread($filename, filesize($filename));
fclose($handle);
echo $contents

// Loop through our array, show HTML source as HTML source; and line numbers too.
//foreach ($lines as $line_num => $line) {
//    echo "Line #<b>{$line_num}</b> : " . htmlspecialchars($line) . "<br />\n";
//}
?>

import scraperwiki

url = "https://ses.ent.northwestern.edu/psp/caesar/EMPLOYEE/HRMS/h/?tab=NWSS_STUDENT"
import urllib                                                                                                             
print urllib.urlopen(url).read() 


# Blank Python


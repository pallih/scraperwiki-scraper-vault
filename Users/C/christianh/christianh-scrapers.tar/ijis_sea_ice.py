# Blank Python

import scraperwiki           
html = scraperwiki.scrape("http://www.ijis.iarc.uaf.edu/en/home/seaice_extent.htm")
print html
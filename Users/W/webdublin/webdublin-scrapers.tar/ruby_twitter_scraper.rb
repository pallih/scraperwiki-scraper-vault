require 'twitter'
 
# Replace the four strings below with your own values.
Twitter.configure do |config|
  
end
 
# Replace the two strings below with the list name and your user name.
Twitter.search('#eurovision', :result_type => 'recent').results
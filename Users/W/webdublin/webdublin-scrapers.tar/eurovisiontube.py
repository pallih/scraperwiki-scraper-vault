import scraperwiki

# Blank Python

url = "http://www.youtube.com/user/eurovision/feed"
import scraperwiki
import lxml.html
import urllib   
import simplejson
import urllib2


# Getting Eurovision 2012 Participants
# scraperwiki.sqlite.save(unique_keys=["country"], data={"country":el.text})
# scraperwiki.sqlite.save(unique_keys=["contestant"], data={"country":el.text))

url = "http://www.eurovision.tv/page/baku-2012/about/shows/participants"           
#scraperwiki.sqlite.execute("delete from swdata") 

country = "Ireland"
singer = "Jedward"
song = "Waterline"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Serbia"
singer = "Željko Joksimović"
song = "Nije Ljubav Stvar"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})


country = "Lithuania"
singer = "Donny Montell"
song = "Love is Blind"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Malta"
singer = "Kurt Calleja"
song = "This is the night"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "F.Y.R. Macedonia"
singer = "Kaliopi"
song = "Crno i belo"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Norway"
singer = "Tooji"
song = "Stay"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Bosnia & Herzegovina"
singer = "MayaSar"
song = "Korake ti znam"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Turkey"
singer = "Can Bonomo"
song = "Love me back"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Estonia"
singer = "Ott Lepland"
song = "Kuula"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Ukraine"
singer = "Gaitana"
song = "Be My Guest"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Albania"
singer = "Rona Nishliu"
song = "Suus"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Sweden"
singer = "Loreen"
song = "Eurphoria"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Moldova"
singer = "Pasha Parfeny"
song = "Lăutar"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Germany"
singer = "Roman Lob"
song = "Spanding Still"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Spain"
singer = "Pastora Soler"
song = "Quédate conmigo"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Greece"
singer = "Eleftheria Eleftheriou"
song = "Aphrodisiac"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Denmark"
singer = "Soluna Samay"
song = "Should've known better"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Romania"
singer = "Mandinga"
song = "Zaleilah"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Azerbaijan"
singer = "Sabina Babayeva"
song = "When the Music Dies"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Italy"
singer = "Nina Zilli"
song = "L'amore è femmina (Out of Love)"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "France"
singer = "Anggun"
song = "Echo (You and I)"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Cyprus"
singer = "Ivi Adamou"
song = "La La Love"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Iceland"
singer = "Gréta Salóme & Jónsi"
song = "Nover Forget"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Russia"
singer = "Buranovskiye Babushki"
song = "Party for Everybody"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "Hungary"
singer = "Compact Disco"
song = "Sound of Our Hearts"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})

country = "United Kingdom"
singer = "Engelbert Humperdinck"
song = "Love Will Set You Free"
scraperwiki.sqlite.save(unique_keys=["country"], data={"country":country, "singer":singer, "song":song})



require 'open-uri'
require 'json'      

url = "https://docs.google.com/spreadsheet/pub?key=0Aj01heFhXLF-dFgyYVp4anJuRnZHYlJ3X2RaczhwX2c&output=html"
# Blank Ruby

import scraperwiki           

scraperwiki.sqlite.attach("hbraun-zamg")


import scraperwiki

search = scraperwiki.swimport('twitter_search_extended').search
search(['ashleymadison'], num_pages=5)
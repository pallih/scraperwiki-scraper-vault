import scraperwiki

url  = "http://apps.irs.gov/app/eos/pub78Search.do?ein1=&names=&city=Detroit&state=MI&country=US&deductibility=all&dispatchMethod=searchCharities&submitName=Search"


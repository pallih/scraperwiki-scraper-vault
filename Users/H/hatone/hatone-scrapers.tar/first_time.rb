
# Blank Ruby
require 'nokogiri'

puts "Hello, coding in the cloud!"    
html = ScraperWiki.scrape("http://fxtrade.oanda.com/orderbook/ordersummary/images/USD_JPYnoncumul.png?i=253.70934582315385)")           

  data = {
    'img' => cells[0].inner_html
  }

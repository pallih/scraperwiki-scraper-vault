# Blank Ruby

require 'rfgraph'

req = RFGraph::Request.new      
  
res= req.get_object("bishopsbark")  # https://graph.facebook.com/


puts res["timelineLikesMetricTitle"]


puts res["name"]
puts res["id"]
puts res["username"]
puts res["category"]
puts res["website"]
puts res["email"]
puts res["phone"]
puts res["about"]
puts res["location"]
puts res["company_overview"]
puts res["description"]   
puts res["general_info"]
puts res["link"]
puts res["likes"]



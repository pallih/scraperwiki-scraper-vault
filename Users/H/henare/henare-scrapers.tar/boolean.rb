ScraperWiki.save_sqlite([:foo], {foo: true, bar: false})

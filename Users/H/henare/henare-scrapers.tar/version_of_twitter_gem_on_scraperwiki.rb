require 'twitter'

puts Twitter::Version::MAJOR
puts Twitter::Version::MINOR
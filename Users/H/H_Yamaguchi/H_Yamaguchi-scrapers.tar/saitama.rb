# -*- coding: utf-8 -*-

require 'rubygems'
require 'open-uri'
require 'nokogiri'
require "addressable/uri"

if RUBY_VERSION < '1.9.0'
  $KCODE = 'UTF8'
end

for i in 0..1000
  url = "http://23.22.7.3/station/locate/"
  puts "Fetching #{i}:#{url}"
  open(url)
  sleep 30
end

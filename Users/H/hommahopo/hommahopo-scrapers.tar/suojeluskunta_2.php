<?php
            $html = scraperWiki::scrape("https://suojeluskunta.com/forum/");
            echo $html;
?>

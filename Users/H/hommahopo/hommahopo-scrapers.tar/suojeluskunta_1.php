<?php
            $html = scraperWiki::scrape("https://suojeluskunta.com/forum/");
            print $html . "\n";
?>

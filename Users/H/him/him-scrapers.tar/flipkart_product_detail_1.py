import scraperwiki
html = scraperwiki.scrape("http://www.flipkart.com/search-books?query=9788120336797")
print html

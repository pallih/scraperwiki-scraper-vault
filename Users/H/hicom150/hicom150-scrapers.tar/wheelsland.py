import scraperwiki           

print "a"

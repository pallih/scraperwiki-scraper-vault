<?php

# Blank PHP

?>

Possible sources for industry scraper:


E Health Insider Intelligence (login required)

SOCITM Insight (login required)

Buying Solutions ()
- suppliers list www.buyingsolutions.gov.uk/suppliers/details/

http://www.intellectuk.org/

SID 4 Gov

SID 4 Health


Possible sources for flu data:

DATA SOURCES FOR HEALTH MONITORING

1. Weekly Data on Communicable and Respiratory Diseases

http://www.rcgp.org.uk/clinical_and_research/rsc/weekly_data.aspx

2. Health Protection Agency real-time syndromic surveillance

http://www.hpa.org.uk/Topics/InfectiousDiseases/InfectionsAZ/RealtimeSyndromicSurveillance/

3. Google Trends / Google News / Google Insights for Search

look at search results e.g. for "flu" to see how this is trending

4. Google Flu Trends

http://www.google.org/flutrends/

5. European Influenza Surveillance Network

http://ecdc.europa.eu/en/activities/surveillance/EISN/Pages/index.aspx


AND POTENTIALLY LOTS MORE RELEVANT STUFF HERE:

"Sources of UK flu data"

http://www.hpa.org.uk/web/HPAweb&HPAwebStandard/HPAweb_C/1195733821514



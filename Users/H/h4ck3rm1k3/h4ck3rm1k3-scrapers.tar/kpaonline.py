import scraperwiki

# Blank Python

# http://www.kpaonline.org/
import scraperwiki           
html = scraperwiki.scrape("http://www.kpaonline.org/")
print html
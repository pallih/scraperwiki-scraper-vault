# Perl Demo
# James michael dupont

import os

script = """
print 'hello perl'; 
"""

with open('script.pl', 'w') as f:
    f.write(script)

os.system("perl script.pl")

